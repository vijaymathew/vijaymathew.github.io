(ns exercise2-solution.core
  (:require
    [clojure.java.jdbc :as j])
  (:import
    [java.sql Statement]))

(def type->getfn
  {:string '.getString
   :int '.getInt
   :float '.getFloat
   :double '.getDouble
   :short '.getShort
   :array '.getArray
   :big-decimal '.getBigDecimal
   :blob '.getBlob
   :boolean '.getBoolean
   :clob '.getClob
   :byte '.getByte
   :bytes '.getBytes
   :timestamp '.getTimestamp
   :time '.getTime
   :date '.getDate})
   
(defn make-rslt-call
  [type-name local-var db-var rslt]
  (if-let [fcall (type-name type->getfn)]
    `[~local-var (~fcall ~rslt (str (quote ~db-var)))]
    (throw (Exception. (str "Invalid type - " type-name)))))
  
(defn make-row-vars
  [bindings rslt]
  (loop [bindings bindings
         vars []]
    (if (seq bindings)
      (let [b (first bindings)]
        (recur (rest bindings)
          (conj vars (make-rslt-call (first b)
                       (second b) (nth b 2) rslt))))
      (into [] (apply concat vars)))))

(defmacro for-each-row
  "(for-each-row dbconn sql-or-statement bindings body)

  `dbconn` is a raw JDBC database connection.

  `sql-or-statement` can be either a SELECT query or a JDBC Statement object.
  If this is a plain String select query, the macro will take care of creating
  and disposing-off the Statement object required to execute the query.

  `bindings` is a vector of vectors in the form [type local-var db-var], where `type` should
  be one of :string, :int, :float, :double, :short, :array, :big-decimal, :blob,
  :boolean, :clob, :byte, :bytes, :timestamp, :time or :date. `local-var` is the name of the variable
  to which a value retrieved from the database is bound. `db-var` is the name of the database column
  from which the value is retrieved. (Note that the syntax of `bindings` differs from the proposed 
  Java extension. A vector of vectors was chosen to ease the implementation.)

  `body` is evaluated in an implicit `do`, in the context of the variable bound by `bindings`.

  An example call to the macro and its resulting expansion is given below:

  (for-each-row dbconn \"SELECT name, salary FROM emp\"
    [[:string n name] [:int s salary]]
    (println n, s))

  ;;=> (let [[rslt stmt] (if (instance? Statement sql-or-statement)
                          [(.executeQuery sql-or-statement) nil]
                         (let [stmt (.createStatement dbconn)]
                           [(.executeQuery stmt sql-or-statement) stmt]))]
        (try
          (loop [next? (.next rslt)]
            (when next?
              (let [n (.getString \"name\")
                    s (.getInt \"salary\")]
                (println n, s))))))"
  [conn sql-stmt bindings & body]
  (let [rslt (gensym)]
    `(let [sql-stmt# ~sql-stmt
           [~rslt stmt#]
           (if (instance? Statement sql-stmt#)
             [(.executeQuery sql-stmt#) nil]
             (let [stmt# (.createStatement ~conn)]
               [(.executeQuery stmt# sql-stmt#) stmt#]))]
       (try
         (loop [next?# (.next ~rslt)]
           (when next?#
             (let ~(make-row-vars bindings rslt)
               ~@body)
             (recur (.next ~rslt))))
         (finally
           (when stmt#
             (.close stmt#)))))))
