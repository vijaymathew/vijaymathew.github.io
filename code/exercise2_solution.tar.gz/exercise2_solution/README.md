Solution to Exercise 2.

See `src/exercise2-solution/core.clj` for implementation details.
Sample code is in `test/exercise2_solution/core_test.clj`, which can
be executed by running `lein test` from the directory.

