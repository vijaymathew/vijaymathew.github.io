(defproject exercise2_solution "0.1.0-SNAPSHOT"
  :description "An implementation for the `for-each-row` macro."
  :url "http://example.com/FIXME"
  :license {:name "Eclipse Public License"
            :url "http://www.eclipse.org/legal/epl-v10.html"}
  :repositories {"local" "file:./maven_repository"}
  :dependencies [[org.clojure/clojure "1.8.0"]
                 [org.clojure/java.jdbc "0.6.1"]
                 [h2/h2 "1.4.193"]]
  :main ^:skip-aot exercise2-solution.core
  :target-path "target/%s"
  :profiles {:uberjar {:aot :all}})
