(ns bit-stream.core-test
  (:require [clojure.test :refer :all]
            [bit-stream.core :refer :all]))

(defn bit-encode
  "Return a byte-array with `data` bit-encoded into it.
  `data` is a vector in the format: 
     [field-name1 value1, field-name2 value2, ...]
  `struct` is a vector in the format:
     [field-name1 bit-field-size1, field-name2 bit-field-size2, ...]
   Values in `data` will be encoded with corresponding 
   bit-field sizes in `struct`.
  `field-names` in both `data` and `struct` are ignored 
   during the encoding process."
  [data struct]
  (let [ba (java.io.ByteArrayOutputStream.)
        encoder (make-writer ba)]
    (loop [data-values (filter integer? data)
           bit-field-sizes (filter integer? struct)]
      (if (and (seq data-values) (seq bit-field-sizes))
        (do (write-bits encoder (first data-values)
              (first bit-field-sizes))
            (recur (rest data-values) (rest bit-field-sizes)))
        (do (when (seq data-values)
              (throw (Exception. "more data values")))
            (when (seq bit-field-sizes)
              (throw (Exception. "more bit field sizes"))))))
    (flush-bits encoder)
    (.toByteArray ba)))

(defn bit-decode
  "Decode a byte-array returned by `bit-encode`.
  `struct` is a vector in the format: 
    [field-name1 bit-field-size1, field-name2 bit-field-size2, ...]
   A new vector is returned with the same field-names 
   as `struct` and the associated values 
   being integers initialized by reading the appropriate number 
   of bits from the encoded stream."
  [encoded-data struct]
  (let [bi (java.io.ByteArrayInputStream. encoded-data)
        decoder (make-reader bi)]
    (loop [field-names (filter keyword? struct)
           bit-field-sizes (filter integer? struct)
           result []]
      (if (seq field-names)
        (recur (rest field-names) (rest bit-field-sizes)
          (concat result [(first field-names)
                          (read-bits decoder (first bit-field-sizes))]))
        (vec result)))))

(def _16bit-color-struct [:red 5 :green 6 :blue 5])

(defn encode-16bit-color
  [color]
  (bit-encode color _16bit-color-struct))

(defn decode-16bit-color
  [encoded-color]
  (bit-decode encoded-color _16bit-color-struct))

(def tcp-header-struct
  [:source-port 16
   :destination-port 16
   :sequence 32
   :acknowledgement-number 32
   :data-offset 4
   :reserved 6
   :urg-flag 1
   :ack-flag 1
   :push-flag 1
   :reset-flag 1
   :syn-flag 1
   :fin-flag 1
   :receive-window-size 16
   :checksum 16
   :urgent-pointer 16])

(defn encode-tcp-header
  [header]
  (bit-encode header tcp-header-struct))

(defn decode-tcp-header
  [encoded-header]
  (bit-decode encoded-header tcp-header-struct))

(deftest tcp-header-test
  (let [sample-header [:source-port 38
                       :destination-port 47892
                       :sequence 1656212531
                       :acknowledgement-number 1481973485
                       :data-offset 5
                       :reserved 0
                       :urg-flag 0
                       :ack-flag 0
                       :push-flag 0
                       :reset-flag 0
                       :syn-flag 0
                       :fin-flag 0
                       :receive-window-size 17664
                       :checksum 888
                       :urgent-pointer 63404]]
    (is (= (decode-tcp-header (encode-tcp-header sample-header)) sample-header))))

(deftest color-test
  (let [sample-color [:red 2 :green 51 :blue 16]]
    (is (= (decode-16bit-color (encode-16bit-color sample-color)) sample-color))))
