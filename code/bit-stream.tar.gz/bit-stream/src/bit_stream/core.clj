(ns bit-stream.core
  (import [bits Reader Writer]))

(defn make-reader
  [input-stream]
  (Reader. input-stream))

(defn read-bit
  [reader]
  (not (zero? (.read reader))))

(defn read-bits
  [reader n]
  (.read reader n))

(defn make-writer
  [output-stream]
  (Writer. output-stream))

(defn flush-bits
  [writer]
  (.flush writer))

(defn write-bit
  [writer b]
  (.write writer (if b 1 0)))

(defn write-bits
  [writer b n]
  (.write writer b n))
