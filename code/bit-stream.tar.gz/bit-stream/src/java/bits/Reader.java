package bits;

import java.io.InputStream;
import java.io.IOException;

/**
 * Read bits from an InputStream.
 */
public class Reader {

    private InputStream bytesInput;
    private int currentByte;
    private int bit;
    
    public Reader(InputStream inputStream) {
        bytesInput = inputStream;
        currentByte = 0;
        bit = 0;
    }

    /**
     * Read the next bit, as either 1 or 0, from `bytesInput`.
     * At the end of the input stream, return -1.
     *
     * If the current bit to check is zero, one byte is read
     * from the stream and is stored in `currentByte`.
     * `bit` is reset to 128 (which is 10000000 in binary).
     * On each invocation of read, each bit in
     * `currentByte` is inspected by halving `bit` until
     * it reaches zero.Then the next byte from the
     * stream is read and the process continues until EOF.
     */
    public int read() throws IOException {
        if (bit == 0) {
            currentByte = bytesInput.read();
            if (currentByte == -1) return currentByte;
            bit = 128;
            return read();
        } else {
            int r = ((currentByte & bit) > 0) ? 1 : 0;
            bit = bit/2;
            return r;
        }
    }

    /**
     * Read the next `n` bits from input, pad those into
     * a single integer value. Return -1 at end of stream.
     */
    public int read(int n) throws IOException {
        if (n <= 0 || n > 32)
            throw new IOException("invalid bit-count in read");
        int r = 0;
        for (int x = n-1; x >= 0; --x) {
            int b = read();
            if (currentByte == -1) return -1;
            r |= (b << x);
        }
        return r;
    }

    /**
     * Align input to the next byte in `bytesInput`.
     */
    public void align() {
        bit = 0;
    }

}

