mk-table def fibs

[def n
 n 1 lteq? 1 [n 1 - fib n 2 - fib +] choose] def find-fib

[def n
 fibs nil n table-get def f
 [n find-fib set f 
  fibs n f table-put .p] def update-fibs
 f nil eq? @update-fibs pick
 f] def fib

5 fib 8 assert .c
10 fib 89 assert .c
20 fib 10946 assert .c
30 fib 1346269 assert .c
100 fib 573147844013817084101 assert .c

'(A procedure that creates the memoized version of
  any single-arity procedure.)

[def proc mk-table def mem-values
 [def n
  mem-values nil n table-get def f
  [@mem-proc n proc set f 
   mem-values n f table-put .p] def update-mem
  f nil eq? @update-mem pick
  f] def mem-proc
 @mem-proc] def memoize

'(A version of `fib` that works with `memoize`.)

[def n def mem-proc
 n 1 lteq? 1 [n 1 - mem-proc n 2 - mem-proc +] choose] def fib

@fib memoize def memo-fib

5 memo-fib 8 assert .c
10 memo-fib 89 assert .c
20 memo-fib 10946 assert .c
30 memo-fib 1346269 assert .c
100 memo-fib 573147844013817084101 assert .c
