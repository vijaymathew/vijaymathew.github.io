'(Merge sort from http://www.scheme.com/tspl4/examples.html#./examples:h2)

[length 0 eq?] def empty?

[def l2 def l1 def pred?
  l1 empty? 
  l2
  [l2 empty? 
   l1
   [l2 first l1 first pred? 
    [l2 first @pred? l1 l2 rest domerge pair]
    [l1 first @pred? l1 rest l2 domerge pair]
    choose]
   choose]
  choose] 
def domerge

[def n def ls def pred?
 n 1 eq? 
 [mk-list ls first push]
 [n 2 quotient def i
  @pred? ls i dosort def a
  @pred? ls i tail n i - dosort def b
  @pred? b a domerge]
 choose]
def dosort

[def ls def pred?
 @pred? ls ls length dosort] 
def merge-sort

'(Tests)

[lt?] [6 7 4] list merge-sort [4 6 7] list assert .c
[lt?] [3 4 2 1 2 5] list merge-sort [1 2 2 3 4 5] list assert .c
[gt?] [3 4 2 1 2 5] list merge-sort [5 4 3 2 2 1] list assert .c
[char-gt?] "coins" string-to-list merge-sort to-string "sonic" assert .c
