'(100 doors problem from http://rosettacode.org/wiki/100_doors)

[def doors def n
 doors [def state def i doors i state not array-set .p] n for-each-n
 doors] def toggle

[def num-doors def n def doors
 n num-doors gt? doors [n doors toggle n 1 + num-doors flip-doors-helper] 
 choose] def flip-doors-helper

[[swap def n [n 1 +] pick] 1 for-each-n] def show-open-doors

[def doors doors 1 doors array-length flip-doors-helper] def flip-doors

[pack-as-list [1 4 9 16 25 36 49 64 81 100] list assert] def check-result

'(Test)
[#f] 100 times pack-as-array flip-doors show-open-doors check-result .c

'(Optimized version)
[def num-doors 1 def square 3 def increment 1 def door
 [door num-doors lteq?] 
 [door square eq? 
  [door increment square + set square 2 increment + set increment] pick
 door 1 + set door] repeat] def optimized-flip-doors

'(Test)
100 optimized-flip-doors check-result
