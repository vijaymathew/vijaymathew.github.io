'(Defines a DSL similar to the one at http://martinfowler.com/articles/languageWorkbench.html#ExternalDsl)

(define (user-name? s)
  (let ((c (string-ref s 0)))
    (or (char=? c #\S) (char=? c #\U))))

(define *current-user-id* #f)

(define (handle-user-name s input)
  (list (c-push (cons trans: (substring s 0 4)))
        (c-push (cons name: (substring s 4 (string-length s))))
        (handle-data (symbol->string (get-symbol input)))
        (c-push *current-user-id*)
        (c-def)))

(define (handle-data s)
  (let ((current-user-id (substring s 0 4)))
    (set! *current-user-id* (string->symbol
                             (string-append "user" current-user-id)))
    (list (c-push (cons id: current-user-id))
          (c-push (cons type: (string->symbol (substring s 4 6))))
          (c-push (cons date: (substring s 6 (string-length s))))
          (c-eval 'pack-as-table))))

(chook! (lambda (expr input)
          (if (symbol? expr)
              (let ((s (symbol->string expr)))
                (if (user-name? s)
                    (handle-user-name s input)
                    #f)))))

'(Accessors for the user object.)

[trans: table-at] def trans
[name: table-at] def name
[id: table-at] def id
[type: table-at] def type
[date: table-at] def date

'(Test. The input is bound to a table object named after the user-id.)

SVCLVIJAY 1001MS20120321
SVCLJOE 1012RT20120401
USAGGLENN 1011MS20120302

'(Validate the objects.)

user1001 trans "SVCL" assert .c
user1011 name "GLENN" assert .c
user1012 id "1012" assert .c
user1012 type RT assert .c
user1001 date "20120321" assert .c