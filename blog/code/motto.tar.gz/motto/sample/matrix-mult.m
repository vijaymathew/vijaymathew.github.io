'(Matrix multiplication. (http://www.scheme.com/tspl4/examples.html#./examples:h1))

[@array apply pack-as-array] def mk-matrix

[def cols def rows
 [cols mk-array] rows times pack-as-array] def mk-empty-matrix

[def a 
 a array? [a array-length 0 gt [a 0 array-at array?] #f choose] #f choose] 
def matrix?

@array-length def matrix-rows
[0 array-at array-length] def matrix-columns

'(Returns the jth element of the ith row.
  Usage: j matrix i matrix-at)
[array-at swap array-at] def matrix-at 

'(Sets the jth element of the ith row to x.
  Usage: j x matrix i matrix-set)
[array-at rot rot array-set] def matrix-set

[def x def m 
 m matrix-rows def rows
 rows mk-array def result
 [def row [m row matrix-at x *] m matrix-columns times-count 
  pack-as-array def r 
  result row r array-set .p] rows times-count
 result] def matrix-scalar-mult

[def m2 def m1
 m2 matrix-rows def nr2
 nr2 m1 matrix-columns eq? not 
 ["Incompatible operands" error]
 [m1 matrix-rows def nr1 
  m2 matrix-columns def nc2
  nr1 nc2 mk-empty-matrix def result
  [def row 
   [def icol 
    [def col col m1 row matrix-at icol m2 col matrix-at *] nr2 times-count 
    [+] collapse icol swap result row matrix-set .p] nc2 times-count] nr1 times-count 
  result] 
 choose] def matrix-matrix-mult

[def y def x
 y number?
 [x number? [x y *] [x y matrix-scalar-mult] choose]
 [x y matrix-matrix-mult] choose] def multiply

'(Tests)
[1 2 3] [4 5 6] mk-matrix def m
m matrix? #t assert .c
m matrix-rows 2 assert .c
m matrix-columns 3 assert .c
1 m 0 matrix-at 2 assert .c
2 m 1 matrix-at 6 assert .c
2 10 m 1 matrix-set
2 m 1 matrix-at 10 assert .c
[1 2 3] array matrix? #f assert .c

10 20 multiply 200 assert .c

[10 20 30] [40 50 100] mk-matrix def r
m 10 multiply r assert .c

[1 2 3] mk-matrix 1/2 multiply set r 
[1/2 1 3/2] mk-matrix r assert .c

[3 -2 -1] [-3 0 -5] [7 -1 -1] mk-matrix -2 multiply set r
[-6 4 2] [6 0 10] [-14 2 2] mk-matrix r assert .c

[1 2 3] mk-matrix def a
[2 3] [3 4] [4 5] mk-matrix def b
a b multiply def r 
[20 26] mk-matrix r assert .c

[2 3 4] [3 4 5] mk-matrix def a
[1] [2] [3] mk-matrix def b
a b multiply def r
[20] [26] mk-matrix r assert .c

[1 2 3] [4 5 6] mk-matrix def a
[1 2 3 4] [2 3 4 5] [3 4 5 6] mk-matrix def b
a b multiply def r
[14 20 26 32] [32 47 62 77] mk-matrix r assert .c

