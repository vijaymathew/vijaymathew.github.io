"test.txt" file open [hello world 10 20 30] list [write #\space write-char] for-each .p close

string-buffer open [hello world 10 20 30] list [write #\space write-char] for-each .p
@read 5 times close .s .c

["hello"] 5 times @string-upcase apply "hello.txt" file open [swap display] collapse close

"www.google.com" 80 tcp-client open "GET /\n" display force-output def p
[p read-line .p] def read-html
read-html [eof? not] [.s .c read-html] repeat
p close