'(Some samples are based on code from "The Scheme Programming Language - Fourth Edition by R. Kent Dybvig"
  (http://www.scheme.com/tspl4/))
     
["hello, world" ] 5 times .s .c

4 5 + 10 * 90 assert .c
1 2 3 4 5 [+] collapse 15 assert .c
1 2 3 4 5 [+] collapse-intact .s .c
1 2 3 4 5 [2 expt] apply [+] collapse 55 assert .c 

[transpose [[*] reduce] for-each [+] collapse] def inner-product
[1 2 3] list [6 5 4] list inner-product 28 assert .c

[def count
 [count 1 + counter] def incr
 []]
def counter

100 counter @ incr @ incr @ incr @ incr @ count 104 assert .c

[def x def y []] def point

10 20 point def a
100 200 point def b
a.x a.y + 30 assert .c
b.x b.y + 300 assert .c

'(inner product)
[transpose [[*] reduce] for-each [+] collapse] def dot-product

[1 2 3] list [6 5 4] list dot-product
28 assert .c

'(filter sum)
[def end def start
 start [dup 1 +] end start - times]
def range

[range pack-as-list @even? filter [+] reduce]
def sum-evens-in-range

1 10 sum-evens-in-range 
30 assert .p

'(find the largest element in a list.)
[@max reduce] def list-max
[2 1 3 5 0] list list-max
5 assert .p

'(Procedure that return multiple values.)
'(a b c quadratic-formula => root1 root2)
[def c def b def a
  b b * a c * 4 * - sqrt def radical
  2 a * def divisor
  0 b - def minsub
  minsub radical + divisor /
  minsub radical - divisor /] def quadratic-formula

2 -4 -6 quadratic-formula
pair 3 -1 pair assert .p

'(Table as an alternative for switch-case.)
[def s [red "stop!" yellow "caution!" green "go!"] table invalid-signal s table-get] 
def respond-to-signal

red respond-to-signal "stop!" assert
yellow respond-to-signal "caution!" assert
green respond-to-signal "go!" assert
orange respond-to-signal invalid-signal assert
.c

'(A compiler definition that creates a keyword `var`
  to define a variable.)
(cdef 'var (lambda (compiler)                                           
             (list (c-push (get-symbol (compiler-input compiler)))        
                   (compile (compiler-input compiler) (compiler-vm compiler))   
                   (c-swap) (c-def))))

var a 100
a 100 assert .c
var b [2 3 *]
b 6 assert .c

'(Demonstrates choice.)
'(x reciprocal => error if x==0 or 1/x)
[dup 0 eq? [.p "zero!" error] [1 swap /] choose] def reciprocal

10 reciprocal 1/10 assert .c
1/10 reciprocal 10 assert .c
0 reciprocal error? #t assert .c
1/10 reciprocal reciprocal 1/10 assert .c

'(Mutiple choice.)
'(income compute-tax => tax)
[def income
 income 10000 lteq?
 [income .05 *]
 [income 20000 lteq?
  [income 10000 - .08 * 500.00 +]
  [income 30000 lteq?
   [income 20000 - .13 * 1300.00 +]
   [income 30000 - .21 * 2600.00 +]
  choose]
 choose]
choose] def compute-tax 
 
5000 compute-tax
250. assert .c
15000 compute-tax
900. assert .c
25000 compute-tax
1950. assert .c
50000 compute-tax
6800. assert .c
 
'(Local variables and variable shadowing.)
10 def x
x 10 assert .c

[100 def x '(Local binding to x will shadow the global binding.)
 x 100 assert .c] !

'(Nested bindings.)
[100 def x
 [200 def x
  x 200 assert .c] !
 x 100 assert .c] !

x 10 assert .c

'(Pair. The simplest compound data type.)
1 2 pair def a
a first 1 assert .c
a second 2 assert .c

[second first] def third
[second second] def fourth

1 2 pair 3 4 pair pair def a
a third 3 assert .c
a fourth 4 assert .c

'(99 bottles)
[dup 1 eq? "bottle" "bottles" choose] def bottles-by-count

[def x 
 x bottles-by-count "of beer on the wall" show .c
 x bottles-by-count "of beer" show .c
 "Take one down, pass it around" show .c
 x 1 - bottles-by-count "of beer on the wall" show .c
 x 1 - 0 gt? [x 1 - bottles] pick] def bottles

'(A+B)
(cdef 'do-sum
      (lambda (compiler)
        (list (c-push (+ (get-number (compiler-input compiler))
                         (get-number (compiler-input compiler)))))))

'(Accumulator)
[def sum [sum + set sum sum]] def accumulator


