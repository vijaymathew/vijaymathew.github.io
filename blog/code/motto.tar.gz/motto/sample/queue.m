'(A module that provides two implementations of a FIFO data structure.
  Usage:
      import "queue.m"
      queue def q
      1 2 3 3 q.mk-bounded-queue [@ enqueue] collapse def a
      [a.dequeue] a.size times      
      => 3 2 1

      1 2 3 4 5 q.mk-unbounded-queue [@ enqueue] collapse def b
      [b.dequeue] b.size times
      => 5 4 3 2 1)

[[def q-size
 q-size mk-array def q
 0 def head
 0 def tail
 [def e
  head q-size gteq ["q overflow" error]
                   [q head q-size remainder e array-set .p
                    head 1 + set head
                   self] choose] 
 def enqueue

 [tail q-size gteq ["q undeflow" error]
                   [tail 1 + set tail
                    head 1 - set head
                    q tail 1 - q-size remainder array-at] choose]
 def dequeue
 [q-size] def size
 []] def bounded-queue

[mk-list def q
 [def e q e append set q self] def enqueue
 [q first q rest set q] def dequeue
 [q length] def size
 []] def unbounded-queue

 @bounded-queue def mk-bounded-queue
 @unbounded-queue def mk-unbounded-queue
[]] def queue