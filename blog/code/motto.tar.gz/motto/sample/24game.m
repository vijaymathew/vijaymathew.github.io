'("24 game" from http://rosettacode.org/wiki/24_game)

[dcompile dexec !] def read!
[[9 random-integer] 4 times .s] def 4digits
[4digits read! 24 eq? "Good job!" "Try again" choose .s .c] def 24game

'(Sample usage:
  > 24game
  3 0 7 1
  => [+ + *]
  "Good job!")