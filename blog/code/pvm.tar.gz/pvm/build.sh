#!/bin/sh

gcc -o bigit.o -c bigit.c
gcc -o vm.o -c vm.c
gcc -o pvm -ldl -lm vm.o bigit.o
gcc -fPIC -c mathlib.c
gcc -shared -Wl,-soname,libmatlib.so.1 -o libmathlib.so bigit.o vm.o mathlib.o

