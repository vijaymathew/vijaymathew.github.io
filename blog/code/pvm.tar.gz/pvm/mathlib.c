/* Sample shared library for FFI.  */
/* Author: Vijay Mathew Pandyalakal <vijay.the.schemer@gmail.com> */
/* See the COPYING file in the same folder as this for details.  */

#include <stdio.h>
#include "vm.h"

void
sqr (pvm *vm)
{
  int a = bigit_to_native_int (&vm->R1);
  bigit res = native_int_to_bigit (a * a);
  vm_mov (vm, &vm->R1, &res);
  /* Print the result: */
  vm_mov (vm, &vm->RD, &vm->R1);
}

