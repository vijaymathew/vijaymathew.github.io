/* Implementation of the Pretentious Virtual Machine.  */
/* Author: Vijay Mathew Pandyalakal <vijay.the.schemer@gmail.com> */
/* See the COPYING file in the same folder as this for details.  */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <assert.h>
#include <time.h>
#include <dlfcn.h>
#include "vm.h"

#define MAX_INPUT_LEN 100 

static const int OS = OS_LINUX;

const char *sample_fn_name = "print_sum";
static void compile_sample_fn (pvm *vm, const char *def);
static void compile_and_run_a_sample_expr (pvm *vm, const char *stmt);
static function *new_fn (void);
static void intern_fn (pvm *vm, function *fn, const char *fnname);

/* command line args. */
static int ARG_TEST_COUNT = -1;
static int ARG_DO_JIT = 0;
static void check_args (int argc, char **argv);
static void print_time_diff (clock_t *start, clock_t *end);
static void print_jit_disclaimer ();

int
main (int argc, char **argv)
{
  char sample_fn_def[100];
  char stmt[100];
  int i;
  clock_t start, end;
  pvm vm;

  check_args (argc, argv);

  init_vm (&vm);

  sprintf (sample_fn_def, "def %s a b: \n    print (a + b)", sample_fn_name);
  compile_sample_fn (&vm, sample_fn_def);

  if (ARG_TEST_COUNT > 0)
    {      
      start = clock();
      for (i = 0; i < ARG_TEST_COUNT; ++i)
        {
          sprintf (stmt, "%s 100 %d", sample_fn_name, i);
          compile_and_run_a_sample_expr (&vm, stmt);
        }
      end = clock();
      print_time_diff (&start, &end);
    }
  else
    {
      char input[MAX_INPUT_LEN + 1];
      while (1)
        {
          printf ("> ");
          fgets (input, MAX_INPUT_LEN, stdin);
          start = clock();
          compile_and_run_a_sample_expr (&vm, input);
          end = clock();
          print_time_diff (&start, &end);
        }
    }
  return 0;
}

void 
init_vm (pvm *vm)
{
  vm->fn_count = 0;
  vm->dlib = NULL;
}

void
release_vm (pvm *vm)
{
  size_t i;

  for (i = 0; i < vm->fn_count; ++i)
    free (vm->fns[i]);
  vm->fn_count = 0;

  if (vm->dlib != NULL)
    dlclose (vm->dlib);
  vm->dlib = NULL;
}

function *
get_fn (pvm *vm, const char *fn_name)
{
  int i;

  for (i = 0; i < vm->fn_count; ++i)
    if (strcmp (vm->syms[i].name, fn_name) == 0)
      return vm->fns[vm->syms[i].index];
  printf ("Function %s is not defined in this VM.\n", fn_name);
  return NULL;
}

static void do_jit (pvm *vm, function *fn);
static void execute_ins (pvm *vm, const instruction *ins);
static void run_native_fn (pvm *vm, const char *fnname);

void
run_fn (pvm *vm, const char *fn_name)
{
  size_t i;
  function *fn = get_fn (vm, fn_name);

  if (fn == NULL)
    exit (1);

  if (fn->native == 1)
    {
      run_native_fn (vm, fn_name);
      return;
    }

  if (ARG_DO_JIT == 1) 
    do_jit (vm, fn);    

  if (fn->native_code != NULL)
    {   
      typedef int (*fptr)(int a, int b);
      fptr f = (fptr) fn->native_code;
      vm->R1 = native_int_to_bigit (f (bigit_to_native_int (&vm->R1), 
                                       bigit_to_native_int (&vm->R2)));    
    }

  for (i = fn->ins_offset; i < fn->ins_count; ++i)
    {
      instruction ins = fn->instructions[i];
      execute_ins (vm, &ins);
    }
}

static void 
run_native_fn (pvm *vm, const char *fnname)
{
  native_fnptr fptr;
  char *err = NULL;

  if (vm->dlib == NULL)
    {
      printf ("No native libraries loaded.\n");
      return;
    }
  fptr = (native_fnptr) dlsym (vm->dlib, fnname);
  if ((err = dlerror()) != NULL)  
    {
      printf ("Failed to run native function: %s\n", err);
      return;
    }
  fptr (vm);
}

void 
vm_add (pvm *vm)
{
  vm->R1 = bigit_add (&vm->R1, &vm->R2);
}

void 
vm_mov (pvm *vm, bigit *dest, const bigit *src)
{
  if (dest == &vm->RD)
    {
      char sb[100];
      bigit_to_string (src, sb);
      printf ("( %s)#%d\n", sb, bigit_to_native_int (src));
    }
  else
    *dest = *src;
}

static void 
compile_sample_fn (pvm *vm, const char *def)
{
  instruction iadd;
  instruction iprint;
  function *fn = new_fn ();

  printf ("\n%s\n\n", def);
  printf ("compiling...\n");

  sleep (1);

  iadd.opc = OPC_ADD;
  iadd.opr1 = &vm->R1;
  iadd.opr2 = &vm->R2;
  fn->instructions[fn->ins_count++] = iadd;

  iprint.opc = OPC_MOV;
  iprint.opr1 = &vm->RD;
  iprint.opr2 = &vm->R1;
  fn->instructions[fn->ins_count++] = iprint;

  intern_fn (vm, fn, sample_fn_name);
}

static void
execute_ins (pvm *vm, const instruction *ins)
{
  switch (ins->opc)
    {
    case OPC_MOV:
      vm_mov (vm, ins->opr1, ins->opr2);
      break;
    case OPC_ADD:
      vm_add (vm);
      break;
    default:
      printf ("invalid opcode.\n");
      exit (1);
    }
}

static void generate_native_code_for_sample_fn (function *, size_t);

static void
do_jit (pvm *vm, function *fn)
{
  static int threshold = 2;

  if (threshold > 0)
    {
      if (ARG_DO_JIT == 1)
        --threshold;
    }
  else if (fn->native_code == NULL && ARG_DO_JIT == 1)
    {      
      /* JIT compile only if fn points to the sample function. */
      if (fn == vm->fns[0]) 
        {
          generate_native_code_for_sample_fn (fn, 1);
        }
    }
}

static void
generate_native_code_for_sample_fn (function *fn, size_t new_offset)
{
  int ins_count = 12;
  char *ins = calloc(ins_count, 1);
  int i = 0;
  size_t j;

  printf ("Just-In-Time compiling ...\n");

  /* x86 assembly code for a function that adds two numbers:

    0:   55                      push   %ebp
    1:   89 e5                   mov    %esp,%ebp
    3:   8b 45 0c                mov    0xc(%ebp),%eax
    6:   03 45 08                add    0x8(%ebp),%eax
    9:   5d                      pop    %ebp
    a:   c3                      ret
    b:   90                      nop

  */

  /* Prologue: */

  /* Push the current base pointer onto the stack, 
     such that it can be restored later. */   
  ins[i++] = 0x55; 
  /* Replaces the old base (frame) pointer 
     with the current stack pointer (which 
     pointed to the top of the old stack) 
     such that the a new stack will be 
     created on top of the old stack. */ 
  ins[i++] = 0x89; ins[i++] = 0xe5; 

  for (j = 0; j < fn->ins_count; ++j)
    {
      if (j >= new_offset)
        {
          /* In the case of the `print_sum` function, `ins_offset` will
             eventually point to the opcode - MOV RD R1. */
          fn->ins_offset = new_offset;
          break;
        }
      
      /* JIT compiler translates each opcode to its equivalent machine 
         instruction (or set of machine instructions). Here we care only
         about the ADD opcode. */
      if (fn->instructions[j].opc = OPC_ADD)
        {
          /* Move the top value on the stack to eax. */
          ins[i++] = 0x8b; ins[i++] = 0x45; ins[i++] = 0x0c; 
          /* Add the top value on the stack with the value in eax. */
          ins[i++] = 0x03; ins[i++] = 0x45; ins[i++] = 0x08; 
          /* Pop the result in the stack and store it i ebp. */
          ins[i++] = 0x5d;
        }
    }

  /* Epilogue: */

  /* Pop the old instruction pointer from the stack 
     and jump to that location. */ 
  ins[i++] = 0xc3; 
  /* NOP. On x86 this does not have any effect. */
  ins[i++] = 0x90;     

  assert (i == ins_count);

  if (fn->native_code != NULL)
    free (fn->native_code);
  fn->native_code = ins;
}

static int
parse_fn_name (const char *s, size_t slen, 
               size_t offset, char *fname)
{
  int i = offset, j = 0;
  char c = 0;
  
  while (i < slen)
    {
      if (isspace (s[i]))
        {
          if (j == 0)
            {
              ++i;
              continue;
            }
          else
            break;
        }
      if (j >= MAX_FN_NAME_LEN)
        return -1;
      else        
        fname[j++] = s[i];
      ++i; 
    }
  fname[j] = 0;
  return i;
}

static int
parse_arg (const char *s, size_t slen, size_t offset, int *out)
{
  int i = offset, j = 0;
  char buf[MAX_BIGIT_LEN + 1];

  while (i < slen)
    {
      if (isspace (s[i]))
        {
          if (j == 0)
            {
              ++i;
              continue;
            }
          else
            break;
        }
      if (j >= MAX_BIGIT_LEN)
        return -1;
      else
        {
          if (isdigit (s[i]))
            buf[j++] = s[i];
        }
      ++i;
    }
  if (j > 0)
    {
      buf[j] = 0;
      *out = atoi (buf);
      return i;
    }
  return -1;
}

static void
intern_native_fn (pvm *vm, const char *fnname)
{
  function *fn = new_fn ();

  fn->native = 1;
  intern_fn (vm, fn, fnname);
}

static void 
intern_fn (pvm *vm, function *fn, const char *fnname)
{
  fn_sym sym;

  if (vm->fn_count > MAX_FN_COUNT)
    {
      printf ("Cannot add more functions to the VM.\n");
      return;
    }

  strcpy (sym.name, fnname);
  sym.index = vm->fn_count;
  vm->syms[vm->fn_count++] = sym;
  vm->fns[sym.index] = fn;
}

static void
load_native_lib (pvm *vm, const char *lib_name)
{
  if (vm->dlib != NULL)
    {
      dlclose (vm->dlib);
      vm->dlib = NULL;
    }
  vm->dlib = dlopen (lib_name, RTLD_LAZY);
  if (!vm->dlib) 
    printf ("Failed to load %s: %s\n", lib_name, dlerror());            
}

static void
localise_libname (const char *lib_name, char *out)
{
  if (OS == OS_W32)
    {
      strcpy (out, lib_name);
      strcat (out, ".dll");
    }
  else if (OS == OS_LINUX)
    {
      strcpy (out, lib_name);
      strcat (out, ".so");
    }
  else
    {
      printf ("FFI not supported in this platform.\n");
      exit (1);
    }
}

static void 
compile_and_run_a_sample_expr (pvm *vm, const char *stmt)
{
  int a, r;
  char s[MAX_FN_NAME_LEN + 1];
  size_t len = strlen (stmt);
  bigit b;

  r = parse_fn_name (stmt, len, 0, s);
  if (r <= 0)
    {
      printf ("Invalid function name.\n");
      return;
    }
  if (strcmp (s, "native") == 0 || strcmp (s, "load") == 0)
    {
      char fn_lib_name[200];

      r = parse_fn_name (stmt, len, r, fn_lib_name);
      if (r <= 0)
        {
          printf ("Invalid function name.\n");
          return;
        }
      if (s[0] == 'n')
        intern_native_fn (vm, fn_lib_name);
      else
        {
          char lib_name[200];

          localise_libname (fn_lib_name, lib_name);
          load_native_lib (vm, lib_name);
        }
    }
  else
    {
      r = parse_arg (stmt, len, r, &a);
      if (r >= 0)
        {
          b = native_int_to_bigit (a);
          vm_mov (vm, &vm->R1, &b);
          r = parse_arg (stmt, len, r,  &a);
          if (r >= 0)
            {
              b = native_int_to_bigit (a);
              vm_mov (vm, &vm->R2, &b);
            }
        }
      run_fn (vm, s);
    }
}

static int
starts_with (const char *s, const char *prefix)
{
  size_t slen = strlen (s);
  size_t plen = strlen (prefix);
  size_t i;

  if (plen > slen) return 0;
  for (i = 0; i < plen; ++i)
    if (s[i] != prefix[i])
      return 0;
  return 1;
}

static void 
check_args (int argc, char **argv)
{
  if (argc > 1)
    {
      int i;

      for (i = 1; i < argc; ++i)
        {
          if (strcmp (argv[i], "-jit") == 0)
            {
              print_jit_disclaimer ();
              ARG_DO_JIT = 1;
            }
          else if (starts_with (argv[i], "-base"))
            set_bigit_base (atoi (argv[i] + strlen ("-base")));
          else if (starts_with (argv[i], "-loop"))
            ARG_TEST_COUNT = atoi (argv[i] + strlen ("-base"));
          else if (strcmp (argv[i], "-h") == 0)
            {
              printf ("Usage: vm [OPTIONS] [TEST_COUNT]\n");
              printf ("Default value of TEST_COUNT is %d\n", ARG_TEST_COUNT);
              printf ("Options are:\n");
              printf ("    -jit    Turn on Just-In-Time compilation. Default is Off.\n");
              printf ("    -baseN  Bigit base. Defaults to 16 (hexadecimal).\n");
              printf ("    -loopN  Call the add function in a loop that runs 0-N times.\n");
              printf ("    -h      Print this help and quit.\n");
              exit (0);
            }
          else
            {
              printf ("Invalid command line option: %s\n", argv[i]);
              exit (1);
            }
        }
    }
}

static function * 
new_fn (void)
{
  function *fn = (function*) malloc (sizeof (function));

  fn->ins_count = 0;
  fn->ins_offset = 0;
  fn->native_code = NULL;
  fn->native = 0;
  return fn;
}

static void 
print_time_diff (clock_t *start, clock_t *end)
{
  printf ("%f secs\n", ((double)(*end - *start)/CLOCKS_PER_SEC));
}

static void 
print_jit_disclaimer ()
{
  char resp[MAX_INPUT_LEN + 1];

  printf ("In JIT mode the VM will run x86 instructions directly on hardware. \n"); 
  printf ("Proceed only if you are running this program on a compatible chip.\n\n"); 
  printf ("Continue? (yes/no) ");
  if (fgets (resp, MAX_INPUT_LEN, stdin))
    {
      size_t i = 0;
      size_t len = strlen (resp);
      
      while (i < len)
        {
          if (isspace (resp[i]))
            {
              resp[i] = 0;
              break;
            }
          ++i;
        }
      if (strcmp (resp, "yes") != 0)
        exit (0);
    }
}
