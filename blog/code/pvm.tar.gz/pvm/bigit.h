/* A high-level representation for numbers.  */
/* Author: Vijay Mathew Pandyalakal <vijay.the.schemer@gmail.com> */
/* See the COPYING file in the same folder as this for details.  */

#ifndef _BIGIT_H_
#define _BIGIT_H_

#define MAX_BIGIT_LEN 20 

typedef struct bigit_
{
  int digits[MAX_BIGIT_LEN];
  size_t len;
} bigit;

void set_bigit_base (int b);
bigit string_to_bigit (const char *s);
bigit native_int_to_bigit (int i);
int bigit_to_native_int (const bigit *b);
void bigit_to_string (const bigit *b, char *out);
bigit bigit_successor (const bigit *b);
bigit bigit_add (const bigit *a, const bigit *b);
void print_bigit (const bigit *b);

#endif
