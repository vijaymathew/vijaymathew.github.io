/* A high-level representation for numbers.  */
/* Author: Vijay Mathew Pandyalakal <vijay.the.schemer@gmail.com> */
/* See the COPYING file in the same folder as this for details.  */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include "bigit.h"

static int DEFAULT_BIGIT_BASE = 2;

void
set_bigit_base (int b)
{
  DEFAULT_BIGIT_BASE = b;
}

bigit 
string_to_bigit (const char *s)
{
  size_t len = strlen (s);
  size_t i;
  int n;
  bigit out;

  n = atoi (s);
  out.len = 0;
  while (n > 0)
    {
      if (n < DEFAULT_BIGIT_BASE)
        {
          out.digits[out.len++] = n;
          n = 0;
        }
      else
        {
          out.digits[out.len++] = n % DEFAULT_BIGIT_BASE;
          n = n / DEFAULT_BIGIT_BASE;
        }
    }
  return out;
}

bigit 
native_int_to_bigit (int i)
{
  char buf[MAX_BIGIT_LEN + 1];

  sprintf (buf, "%d", i);
  return string_to_bigit (buf);
}

int 
bigit_to_native_int (const bigit *b)
{
  size_t i;
  int r = 0;

  for (i = 0; i < b->len; ++i)
    r += (b->digits[i] * ((int) pow (DEFAULT_BIGIT_BASE, i)));
  return r;
}

void 
bigit_to_string (const bigit *b, char *out)
{
  size_t i, k = 0;  

  for (i = 0; i < b->len; ++i)
    {
      char buf[10];
      size_t j, len;
      
      sprintf (buf, "%d", b->digits[i]);
      len = strlen (buf);
      for (j = 0; j < len; ++j)
        out[k++] = buf[j];
      out[k++] = ' ';
    }
  out[k] = 0;
}

bigit 
bigit_successor (const bigit *b)
{
  int r = bigit_to_native_int (b) + 1;
  char buf[MAX_BIGIT_LEN + 1];

  sprintf (buf, "%d", r);
  return string_to_bigit (buf);
}

bigit 
bigit_add (const bigit *a, const bigit *b)
{
  bigit result;
  int start = 0;
  int end = bigit_to_native_int (b);

  result.len = 0;
  while (start < end)
    {
      result = bigit_successor (a);
      a = &result;
      ++start;
    }
  return result;
}

void 
print_bigit (const bigit *b)
{
  size_t i;
  
  for (i = 0; i < b->len; ++i)
    printf ("%d ", b->digits[i]);
  printf ("\n");
}
