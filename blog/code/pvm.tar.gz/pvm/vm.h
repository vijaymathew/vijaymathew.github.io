/* Interface of the Pretentious Virtual Machine.  */
/* Author: Vijay Mathew Pandyalakal <vijay.the.schemer@gmail.com> */
/* See the COPYING file in the same folder as this for details.  */

#ifndef _VM_H_
#define _VM_H_

#include "bigit.h"

#define OS_LINUX 1
#define OS_W32 2

typedef char opcode;

#define OPC_MOV 1
#define OPC_ADD 2

typedef struct instruction_
{
  opcode opc;
  bigit *opr1;
  bigit *opr2;
} instruction;

#define MAX_INS_COUNT 10
#define MAX_FN_NAME_LEN 20

typedef struct function_
{
  instruction instructions[MAX_INS_COUNT];
  size_t ins_count;
  size_t ins_offset;
  char *native_code;
  int native;
} function;

typedef struct fn_sym_
{
  char name[MAX_FN_NAME_LEN + 1];
  int index;
} fn_sym;

#define MAX_FN_COUNT 10

typedef struct pvm_
{
  function *fns[MAX_FN_COUNT]; /* The table of interned functions. */
  fn_sym syms[MAX_FN_COUNT];
  int fn_count;
  bigit R1;
  bigit R2;
  bigit RD; /* Display. */
  void *dlib; /* Native library handle. */
} pvm;

/* Signature of native functions. */
typedef void (*native_fnptr)(pvm *);

void init_vm (pvm *vm);
void release_vm (pvm *vm);
function *get_fn (pvm *vm, const char *fn_name);
void run_fn (pvm *vm, const char *fn_name);

void vm_mov (pvm *vm, bigit *dest, const bigit *src);
void vm_add (pvm *vm);

#endif

