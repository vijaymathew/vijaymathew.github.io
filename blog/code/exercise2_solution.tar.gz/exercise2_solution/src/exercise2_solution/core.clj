(ns exercise2-solution.core
  "Solution to exercise 2 in the blog post https://lispchronicles.wordpress.com/2017/02/22/syntactic-abstractions/"
  (:import
    [java.sql Statement]))

(defn make-fetcher
  "Create and return the binding vector for `let` that reads the column values."
  [bindings resultset-sym]
  (->> bindings
    (mapcat (fn [[sym col]]
              [sym `(.getObject ~resultset-sym ~col)]))
    vec))

(defmacro for-each-row
  "(for-each-row jdbc-statement bindings body)
  
  `sql-statement` must be a JDBC Statement object.
  
  `bindings` is a vector of vectors in the form [local-var db-var]. `local-var` is the name of the variable
  to which a value retrieved from the database is bound. `db-var` is the name of the database column
  from which the value is retrieved. (Note that the syntax of `bindings` differs from the Java extension
  proposed in the blog post.)
  
  `body` is evaluated in the context of the variable bound by `bindings`.
  
  An example call to the macro and its resulting expansion is given below:
  
  (for-each-row stmt
    [[n \"name\"] [s \"salary\"]]
     (println n, s))

  ;;=> (let [resultset (.executeQuery sql-statement)]
         (while (.next resultset)
           (let [n (.getObject resultset \"name\")
                 s (.getObject resultset \"salary\")]
             (println n, s))))"
  [jdbc-statement bindings & body]
  (let [resultset-sym (gensym)]
    `(with-open [~resultset-sym (.executeQuery ~jdbc-statement)]
       (while (.next ~resultset-sym)
         (let ~(make-fetcher bindings resultset-sym)
           ~@body)))))

