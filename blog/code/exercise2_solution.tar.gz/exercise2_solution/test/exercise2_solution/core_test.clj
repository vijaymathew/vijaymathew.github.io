(ns exercise2-solution.core-test
  (:require
    [clojure.test :refer :all]
    [exercise2-solution.core :refer :all])
  (:import
    [java.sql DriverManager]))

(def data {"abc" 1500 "defg" 900 "hij" 1550})

(defn setup-schema
  [conn]
  (println "setting up...")
  (with-open [stmt (.createStatement conn)]
    (.execute stmt "DROP TABLE IF EXISTS employee")
    (.execute stmt "DROP TABLE IF EXISTS test")
    (.execute stmt "CREATE TABLE employee (name VARCHAR(50), salary INT)")
    (doseq [row data]
      (.execute stmt (str "INSERT INTO employee VALUES('" (first row) "'," (second row) ")")))
    (.execute stmt "CREATE TABLE test (f FLOAT, d DOUBLE, s SMALLINT, b TINYINT, bb BOOLEAN, tt TIME, dt DATE, ts TIMESTAMP)")
    (.execute stmt "INSERT INTO TEST VALUES(1.4, 3.14, 22, 12, 1, '11:30:23', '2017-02-20', '2017-01-30 02:32:45')")))

(defn teardown-schema
  [conn]
  (println "tearing down...")
  (with-open [stmt (.createStatement conn)]
    (.execute stmt "DROP TABLE IF EXISTS employee")
    (.execute stmt "DROP TABLE IF EXISTS test")))

(def dbconn (atom nil))

(defn init
  [f]
  (Class/forName "org.h2.Driver")
  (with-open [conn (DriverManager/getConnection
                     "jdbc:h2:~/test", "sa", "")]
    (reset! dbconn conn)
    (setup-schema conn)
    (f)
    (teardown-schema conn)))

(use-fixtures :once init)

(deftest stmt-test
  (testing "Testing direct SQL query..."
    (with-open [stmt (.prepareStatement @dbconn "SELECT name, salary FROM employee")]
      (for-each-row stmt
        [[emp-name "name"]
         [emp-salary "salary"]]
        (is (= (get data emp-name) emp-salary))))))

(deftest pstmt-test
  (testing "Testing prepared-statement query..."
    (with-open [stmt (.prepareStatement @dbconn "SELECT name, salary FROM employee WHERE salary > ?")]
      (let [sum (atom 0)]
        (.setInt stmt 1 1000)
        (for-each-row stmt
          [[emp-name "name"]
           [emp-salary "salary"]]
          (is (= (get data emp-name) emp-salary))
          (reset! sum (+ emp-salary @sum)))
        (is (= @sum (+ 1500 1550)))))))

(deftest types-test
  (testing "Various datatype mappings..."
    (with-open [stmt (.prepareStatement @dbconn "SELECT f, d, s, b, bb, tt, dt, ts FROM test")]
      (for-each-row stmt
        [[f "f"]
         [d "d"]
         [s "s"]
         [b "b"]
         [bb "bb"]
         [tt "tt"]
         [dt "dt"]
         [ts "ts"]]
        (is (= f 1.4))
        (is (= d 3.14))
        (is (= s 22))
        (is (= b 12))
        (is (= bb true))
        (is (= "11:30:23" (str tt)))
        (is (= "2017-02-20" (str dt)))
        (is (= "2017-01-30 02:32:45.0" (str ts)))))))
