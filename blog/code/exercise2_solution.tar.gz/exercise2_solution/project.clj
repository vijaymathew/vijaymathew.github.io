(defproject exercise2_solution "0.1.0-SNAPSHOT"
  :description "An implementation for the `for-each-row` macro."
  :url "http://example.com/FIXME"
  :license {:name "The MIT License"
            :url "https://opensource.org/licenses/MIT"}
  :dependencies [[org.clojure/clojure "1.8.0"]
                 [com.h2database/h2 "1.4.193"]]
  :main ^:skip-aot exercise2-solution.core
  :target-path "target/%s"
  :profiles {:uberjar {:aot :all}})
