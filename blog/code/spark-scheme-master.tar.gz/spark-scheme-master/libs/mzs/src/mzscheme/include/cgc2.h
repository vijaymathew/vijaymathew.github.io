
extern void **GC_variable_stack;
