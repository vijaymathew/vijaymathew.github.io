
/* gc.h -> sgc.h */
#include "sgc.h"
