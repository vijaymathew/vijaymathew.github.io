
/* PLTSCHEME: stub for old paths: */
#include "include/gc.h"
