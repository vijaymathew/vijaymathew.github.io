
enum {
  mzu_Cn, /* this one should be first */
  mzu_Cc,
  mzu_Cf,
  mzu_Cs,
  mzu_Co,
  mzu_Ll,
  mzu_Lu,
  mzu_Lt,
  mzu_Lm,
  mzu_Lo,
  mzu_Nd,
  mzu_Nl,
  mzu_No,
  mzu_Ps,
  mzu_Pe,
  mzu_Pi,
  mzu_Pf,
  mzu_Pc,
  mzu_Pd,
  mzu_Po,
  mzu_Mn,
  mzu_Mc,
  mzu_Me,
  mzu_Sc,
  mzu_Sk,
  mzu_Sm,
  mzu_So,
  mzu_Zl,
  mzu_Zp,
  mzu_Zs
};
#define mzu_LAST mzu_Zs
