
/* gc.h -> gc2.h */
#include "gc2.h"
