(defproject url-shortner-service "0.1"
  :min-lein-version "2.0.0"
  :dependencies [[org.clojure/clojure "1.8.0"]
                 [com.sparkjava/spark-core "2.7.1"]
                 [ch.qos.logback/logback-classic "1.0.13"]
                 [cheshire "5.8.0"]]
  :main url-shortner.core)
                 
