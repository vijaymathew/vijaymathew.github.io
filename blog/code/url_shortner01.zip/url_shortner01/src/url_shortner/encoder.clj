(ns url-shortner.encoder
  (:require [clojure.string :as s]))

(def ^String base62-lookup "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")

(defn decimal->b62
  [n]
  (loop [n n, rs []]
    (if (zero? n)
      (s/join (reverse rs))
      (let [[q r] [(quot n 62) (rem n 62)]]
        (recur q (conj rs (.charAt base62-lookup (Math/abs r))))))))

(defn encode
  [^String url]
  (decimal->b62 (.hashCode url)))
