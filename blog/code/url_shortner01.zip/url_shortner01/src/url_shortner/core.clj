(ns url-shortner.core
  (:require [cheshire.core :as json]
            [url-shortner.encoder :as e])
  (:import [spark Spark Route Request Response]
           [org.slf4j Logger LoggerFactory]))

(def logger (LoggerFactory/getLogger "urlshortner.core"))

(def db (atom {}))

(defn post-handler
  [request response]
  (try
    (let [r (json/parse-string (.body request) true)
          url (:url r)
          short-url (e/encode url)]
      (swap! db assoc short-url url)
      (.status response 200)
      (.header response "Content-Type" "application/json")
      (json/generate-string {:hash short-url}))
    (catch Exception ex
      (.error logger (str "Failed to process POST request." (.getMessage ex)))
      (throw ex))))

(defn get-handler
  [request response]
  (if-let [url (get @db (.params request ":hash"))]
    (.redirect response url)
    (.status response 404)))

(defn handler
  [f]
  (reify Route
    (handle [_ ^Request request ^Response response]
      (f request response))))

(defn -main
  []
  (Spark/get "/:hash" (handler get-handler))

  (Spark/post "/" (handler post-handler)))
