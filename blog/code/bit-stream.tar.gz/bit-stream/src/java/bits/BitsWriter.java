package bits;

import java.io.OutputStream;
import java.io.IOException;

/**
 * Write bits to an OutputStream.
 */
public class BitsWriter {

    private OutputStream bytesOutput;
    private int currentByte;
    private int bit;

    public BitsWriter(OutputStream output) {
        bytesOutput = output;
        currentByte = 0;
        bit = 7;
    }

    /**
     * If atleast one bit was padded to `currentByte`,
     * write it to the underlying OutputStream.
     */
    public void flush() throws IOException {
        if (bit < 7) bytesOutput.write(currentByte);
        currentByte = 0;
        bit = 7;
    }

    /**
     * If `b` is not zero, turn on the bit in `currentByte` at
     * position `bit`. If one byte is full, flush that to the
     * OutputStream.
     */
    public void write(int b) throws IOException {
        if (bit == -1) {
            flush();
            write(b);
        } else {
            if (b != 0) currentByte |= (1 << bit);
            bit -= 1;
        }
    }

    /**
     * Extract `n` bits from the integer `b` and write that to
     * the OutputStream.
     */
    public void write(int b, int n) throws IOException {
        if (n <= 0 || n > 32)
            throw new IOException("invalid bit-count in write");
        for (int x = n-1; x >= 0; --x)
            write(b & (1 << x));
    }
}
