package bits;

import java.io.InputStream;
import java.io.IOException;

/**
 * Read bits from an InputStream.
 */
public class BitsReader {

    private InputStream bytesInput;
    private int currentByte;
    private int bit;
    
    public BitsReader(InputStream inputStream) {
        bytesInput = inputStream;
        currentByte = 0;
        bit = 0;
    }

    /**
     * Read the next bit, as either 1 or 0, from `bytesInput`.
     * At the end of the input stream, return -1.
     */
    public int read() throws IOException {
        // `currentByte` is exhausted of bits, read the next byte
        // from the InputStream.
        if (bit == 0) {
            currentByte = bytesInput.read();
            if (currentByte == -1) return currentByte;
            // Reset bit index to the beginning of `currentByte`.
            // 128 = 10000000 in binary.
            bit = 128;
            return read();
        } else {
            // If `bit` is on in currentByte, return 1, if it
            // is off, return 0.
            int r = ((currentByte & bit) > 0) ? 1 : 0;
            // Halving `bit` get the index ready to check for the
            // next bit in `currentByte`.
            bit = bit/2;
            return r;
        }
    }

    /**
     * Read the next `n` bits from input, pad those into
     * a single integer value. Return -1 at end of stream.
     */
    public int read(int n) throws IOException {
        if (n <= 0 || n > 32)
            throw new IOException("invalid bit-count in read");
        int r = 0;
        for (int x = n-1; x >= 0; --x) {
            int b = read();
            if (currentByte == -1) return -1;
            r |= (b << x);
        }
        return r;
    }

    /**
     * Align input to the next byte in `bytesInput`.
     */
    public void align() {
        bit = 0;
    }
}
