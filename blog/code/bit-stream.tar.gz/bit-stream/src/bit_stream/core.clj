(ns bit-stream.core
  (import [bits BitsReader BitsWriter]))

(defn make-reader
  [input-stream]
  (BitsReader. input-stream))

(defn read-bit
  [reader]
  (not (zero? (.read reader))))

(defn read-bits
  [reader n]
  (.read reader n))

(defn make-writer
  [output-stream]
  (BitsWriter. output-stream))

(defn flush-bits
  [writer]
  (.flush writer))

(defn write-bit
  [writer b]
  (.write writer (if b 1 0)))

(defn write-bits
  [writer b n]
  (.write writer b n))

(defn bit-encode
  "Return a byte-array with `data` bit-encoded into it.
  `data` is a vector in the format: 
     [field-name1 value1, field-name2 value2, ...]
  `spec` is a vector in the format:
     [field-name1 bit-field-size1, field-name2 bit-field-size2, ...]
   Values in `data` will be encoded with corresponding 
   bit-field sizes in `spec`.
  `field-names` in both `data` and `spec` are ignored 
   during the encoding process."
  [data spec]
  (let [ba (java.io.ByteArrayOutputStream.)
        encoder (make-writer ba)]
    (loop [data-values (filter integer? data)
           bit-field-sizes (filter integer? spec)]
      (if (and (seq data-values) (seq bit-field-sizes))
        (do (write-bits encoder (first data-values)
              (first bit-field-sizes))
            (recur (rest data-values) (rest bit-field-sizes)))
        (do (when (seq data-values)
              (throw (Exception. "more data values")))
            (when (seq bit-field-sizes)
              (throw (Exception. "more bit field sizes"))))))
    (flush-bits encoder)
    (.toByteArray ba)))

(defn bit-decode
  "Decode a byte-array returned by `bit-encode`.
  `spec` is a vector in the format: 
    [field-name1 bit-field-size1, field-name2 bit-field-size2, ...]
   A new vector is returned with the same field-names 
   as `spec` and the associated values 
   being integers initialized by reading the appropriate number 
   of bits from the encoded stream."
  [encoded-data spec]
  (let [bi (java.io.ByteArrayInputStream. encoded-data)
        decoder (make-reader bi)]
    (loop [field-names (filter keyword? spec)
           bit-field-sizes (filter integer? spec)
           result []]
      (if (seq field-names)
        (recur (rest field-names) (rest bit-field-sizes)
          (concat result [(first field-names)
                          (read-bits decoder (first bit-field-sizes))]))
        (vec result)))))
