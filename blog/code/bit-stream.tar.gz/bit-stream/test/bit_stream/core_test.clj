(ns bit-stream.core-test
  (:require [clojure.test :refer :all]
            [bit-stream.core :refer :all]))

(def _16bit-color-spec [:red 5 :green 6 :blue 5])

(defn encode-16bit-color
  [color]
  (bit-encode color _16bit-color-spec))

(defn decode-16bit-color
  [encoded-color]
  (bit-decode encoded-color _16bit-color-spec))

(def tcp-header-spec
  [:source-port 16
   :destination-port 16
   :sequence 32
   :acknowledgement-number 32
   :data-offset 4
   :reserved 6
   :urg-flag 1
   :ack-flag 1
   :push-flag 1
   :reset-flag 1
   :syn-flag 1
   :fin-flag 1
   :receive-window-size 16
   :checksum 16
   :urgent-pointer 16])

(defn encode-tcp-header
  [header]
  (bit-encode header tcp-header-spec))

(defn decode-tcp-header
  [encoded-header]
  (bit-decode encoded-header tcp-header-spec))

(deftest tcp-header-test
  (let [sample-header [:source-port 38
                       :destination-port 47892
                       :sequence 1656212531
                       :acknowledgement-number 1481973485
                       :data-offset 5
                       :reserved 0
                       :urg-flag 0
                       :ack-flag 0
                       :push-flag 0
                       :reset-flag 0
                       :syn-flag 0
                       :fin-flag 0
                       :receive-window-size 17664
                       :checksum 888
                       :urgent-pointer 63404]]
    (is (= (decode-tcp-header (encode-tcp-header sample-header)) sample-header))))

(deftest color-test
  (let [sample-color [:red 2 :green 51 :blue 16]]
    (is (= (decode-16bit-color (encode-16bit-color sample-color)) sample-color))))
