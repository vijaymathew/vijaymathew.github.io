# bit-stream

A Clojure library for performing IO on bit streams.

## License

Copyright © 2017 Vijay Mathew Pandyalakal <vijay.the.lisper@gmail.com>

Distributed under the Eclipse Public License either version 1.0 or (at
your option) any later version.
