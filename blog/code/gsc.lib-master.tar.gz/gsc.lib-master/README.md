gsc.lib
=======

A collection of Gambit Scheme libraries, mostly for UNIX system programming.

Follow these steps to build the code:

    1. Install Gambit-C (http://dynamo.iro.umontreal.ca/wiki/index.php/Main_Page) and a standards compliant C compiler.
    2. Run the configure script: `./configure' or `gsi -f configure'.
    3. Change directory to the source folder and run make: `cd ./src; make'
    4. Type `./gsc.lib.repl' to launch the REPL.