#include <iostream>
#include <utility>
#include <vector>
#include <map>
#include <cassert>
#include "calendar.h"
#include "egyptian.h"
#include "armenian.h"
#include "gregorian.h"
#include "coptic.h"
#include "ethiopic.h"
#include "iso.h"
#include "islamic.h"
#include "hindu.h"
#include "hindu_lunar.h"
#include "mayan.h"
using namespace std;
using namespace calendar;

static const bool TEST_ALL = true;
static const bool PRINT_RESULT = false;

enum CalendarId { EGYPTIAN, ARMENIAN, GREGORIAN, COPTIC,
                  ETHIOPIC, ISO_C, ISLAMIC, HINDU,
                  HINDU_LUNAR };

typedef vector<Calendar*> Calendars;
typedef pair<int, Calendars> IntCal;
typedef vector<IntCal> IntCals;
typedef pair<int, util::CommonDayOfWeek> IntDow;
typedef vector<IntDow> IntDows;
typedef map<int, util::CommonDayOfWeek> IntDowMap;
typedef vector<int> Rds;
static IntCals test_dates;
static IntDowMap test_dows;

static void test ();

int
main ()
{
  test ();
  return 0;
}

static Calendars init_test_checks (Calendar* c);
static void finish_test_checks (Calendars& t, int rd, 
                                util::CommonDayOfWeek dow);

static void 
init_tests ()
{
  {
    IntDows rds;
    rds.push_back (make_pair (-214193, util::SUN));
    if (TEST_ALL)
      {
        rds.push_back (make_pair (-61387, util::WED));
        rds.push_back (make_pair (25469, util::WED));
        rds.push_back (make_pair (49217, util::SUN));
        rds.push_back (make_pair (171307, util::WED));
        rds.push_back (make_pair (210155, util::MON));
        rds.push_back (make_pair (253427, util::SAT));
        rds.push_back (make_pair (369740, util::SUN));
        rds.push_back (make_pair (400085, util::SUN));
        rds.push_back (make_pair (434355, util::FRI));
        rds.push_back (make_pair (452605, util::SAT));
        rds.push_back (make_pair (470160, util::FRI));
        rds.push_back (make_pair (473837, util::SUN));
        rds.push_back (make_pair (507850, util::SUN));
        rds.push_back (make_pair (524156, util::WED));
        rds.push_back (make_pair (544676, util::SAT));
        rds.push_back (make_pair (567118, util::SAT));
        rds.push_back (make_pair (569477, util::SAT));
        rds.push_back (make_pair (601716, util::WED));
        rds.push_back (make_pair (613424, util::SUN));
        rds.push_back (make_pair (626596, util::FRI));
        rds.push_back (make_pair (645554, util::SUN));
        rds.push_back (make_pair (664224, util::MON));
        rds.push_back (make_pair (671401, util::WED));
        rds.push_back (make_pair (694799, util::SUN));
        rds.push_back (make_pair (704424, util::SUN));
        rds.push_back (make_pair (708842, util::MON));
        rds.push_back (make_pair (709409, util::MON));
        rds.push_back (make_pair (709580, util::THU));
        rds.push_back (make_pair (727274, util::TUE));
        rds.push_back (make_pair (728714, util::SUN));
        rds.push_back (make_pair (744313, util::WED));
        rds.push_back (make_pair (764652, util::SUN));
      }

    Calendars egyptian;
    egyptian.push_back (new Egyptian (161, 7, 15));
    egyptian.push_back (new Egyptian (580, 3, 6));
    egyptian.push_back (new Egyptian (818, 2, 22));
    egyptian.push_back (new Egyptian (883, 3, 15));
    egyptian.push_back (new Egyptian (1217, 9, 15));
    egyptian.push_back (new Egyptian (1324, 2, 18));
    egyptian.push_back (new Egyptian (1442, 9, 10));
    egyptian.push_back (new Egyptian (1761, 5, 8));
    egyptian.push_back (new Egyptian (1844, 6, 28));
    egyptian.push_back (new Egyptian (1938, 5, 18));
    egyptian.push_back (new Egyptian (1988, 5, 18));
    egyptian.push_back (new Egyptian (2036, 6, 23));
    egyptian.push_back (new Egyptian (2046, 7, 20));
    egyptian.push_back (new Egyptian (2139, 9, 28));
    egyptian.push_back (new Egyptian (2184, 5, 29));
    egyptian.push_back (new Egyptian (2240, 8, 19));
    egyptian.push_back (new Egyptian (2302, 2, 11));
    egyptian.push_back (new Egyptian (2308, 7, 30));
    egyptian.push_back (new Egyptian (2396, 11, 29));
    egyptian.push_back (new Egyptian (2428, 12, 27));
    egyptian.push_back (new Egyptian (2465, 1, 24));
    egyptian.push_back (new Egyptian (2517, 1, 2));
    egyptian.push_back (new Egyptian (2568, 2, 27));
    egyptian.push_back (new Egyptian (2587, 10, 29));
    egyptian.push_back (new Egyptian (2651, 12, 7));
    egyptian.push_back (new Egyptian (2678, 4, 17));
    egyptian.push_back (new Egyptian (2690, 5, 25));
    egyptian.push_back (new Egyptian (2691, 12, 17));
    egyptian.push_back (new Egyptian (2692, 6, 3));
    egyptian.push_back (new Egyptian (2740, 11, 27));
    egyptian.push_back (new Egyptian (2744, 11, 7));
    egyptian.push_back (new Egyptian (2787, 8, 1));
    egyptian.push_back (new Egyptian (2843, 4, 20));
    
    Calendars armenian;
    armenian.push_back (new Armenian (-1138, 4, 10));
    armenian.push_back (new Armenian (-720, 12, 6));
    armenian.push_back (new Armenian (-482, 11, 22));
    armenian.push_back (new Armenian (-417, 12, 15));
    armenian.push_back (new Armenian (-82, 6, 10));
    armenian.push_back (new Armenian (24, 11, 18));
    armenian.push_back (new Armenian (143, 6, 5));
    armenian.push_back (new Armenian (462, 2, 3));
    armenian.push_back (new Armenian (545, 3, 23));
    armenian.push_back (new Armenian (639, 2, 13));
    armenian.push_back (new Armenian (689, 2, 13));
    armenian.push_back (new Armenian (737, 3, 18));
    armenian.push_back (new Armenian (747, 4, 15));
    armenian.push_back (new Armenian (840, 6, 23));
    armenian.push_back (new Armenian (885, 2, 24));
    armenian.push_back (new Armenian (941, 5, 14));
    armenian.push_back (new Armenian (1002, 11, 11));
    armenian.push_back (new Armenian (1009, 4, 25));
    armenian.push_back (new Armenian (1097, 8, 24));
    armenian.push_back (new Armenian (1129, 9, 22));
    armenian.push_back (new Armenian (1165, 10, 24));
    armenian.push_back (new Armenian (1217, 10, 2));
    armenian.push_back (new Armenian (1268, 11, 27));
    armenian.push_back (new Armenian (1288, 7, 24));
    armenian.push_back (new Armenian (1352, 9, 2));
    armenian.push_back (new Armenian (1379, 1, 12));
    armenian.push_back (new Armenian (1391, 2, 20));
    armenian.push_back (new Armenian (1392, 9, 12));
    armenian.push_back (new Armenian (1393, 2, 28));
    armenian.push_back (new Armenian (1441, 8, 22));
    armenian.push_back (new Armenian (1445, 8, 2));
    armenian.push_back (new Armenian (1488, 4, 26));
    armenian.push_back (new Armenian (1544, 1, 15));
    
    Calendars gregorian;
    gregorian.push_back (new Gregorian (-586, 7, 24));
    gregorian.push_back (new Gregorian (-168, 12, 5));
    gregorian.push_back (new Gregorian (70, 9, 24));
    gregorian.push_back (new Gregorian (135, 10, 2));
    gregorian.push_back (new Gregorian (470, 1, 8));
    gregorian.push_back (new Gregorian (576, 5, 20));
    gregorian.push_back (new Gregorian (694, 11, 10));
    gregorian.push_back (new Gregorian (1013, 4, 25));
    gregorian.push_back (new Gregorian (1096, 5, 24));
    gregorian.push_back (new Gregorian (1190, 3, 23));
    gregorian.push_back (new Gregorian (1240, 3, 10));
    gregorian.push_back (new Gregorian (1288, 4, 2));
    gregorian.push_back (new Gregorian (1298, 4, 27));
    gregorian.push_back (new Gregorian (1391, 6, 12));
    gregorian.push_back (new Gregorian (1436, 2, 3));
    gregorian.push_back (new Gregorian (1492, 4, 9));
    gregorian.push_back (new Gregorian (1553, 9, 19));
    gregorian.push_back (new Gregorian (1560, 3, 5));
    gregorian.push_back (new Gregorian (1648, 6, 10));
    gregorian.push_back (new Gregorian (1680, 6, 30));
    gregorian.push_back (new Gregorian (1716, 7, 24));
    gregorian.push_back (new Gregorian (1768, 6, 19));
    gregorian.push_back (new Gregorian (1819, 8, 2));
    gregorian.push_back (new Gregorian (1839, 3, 27));
    gregorian.push_back (new Gregorian (1903, 4, 19));
    gregorian.push_back (new Gregorian (1929, 8, 25));
    gregorian.push_back (new Gregorian (1941, 9, 29));
    gregorian.push_back (new Gregorian (1943, 4, 19));
    gregorian.push_back (new Gregorian (1943, 10, 7));
    gregorian.push_back (new Gregorian (1992, 3, 17));
    gregorian.push_back (new Gregorian (1996, 2, 25));
    gregorian.push_back (new Gregorian (2038, 11, 10));
    gregorian.push_back (new Gregorian (2094, 7, 18));

    Calendars coptic;
    coptic.push_back (new Coptic (-870, 12, 6));
    coptic.push_back (new Coptic (-451, 4, 12));
    coptic.push_back (new Coptic (-213, 1, 29));
    coptic.push_back (new Coptic (-148, 2, 5));
    coptic.push_back (new Coptic (186, 5, 12));
    coptic.push_back (new Coptic (292, 9, 23));
    coptic.push_back (new Coptic (411, 3, 11));
    coptic.push_back (new Coptic (729, 8, 24));
    coptic.push_back (new Coptic (812, 9, 23));
    coptic.push_back (new Coptic (906, 7, 20));
    coptic.push_back (new Coptic (956, 7, 7));
    coptic.push_back (new Coptic (1004, 7, 30));
    coptic.push_back (new Coptic (1014, 8, 25));
    coptic.push_back (new Coptic (1107, 10, 10));
    coptic.push_back (new Coptic (1152, 5, 29));
    coptic.push_back (new Coptic (1208, 8, 5));
    coptic.push_back (new Coptic (1270, 1, 12));
    coptic.push_back (new Coptic (1276, 6, 29));
    coptic.push_back (new Coptic (1364, 10, 6));
    coptic.push_back (new Coptic (1396, 10, 26));
    coptic.push_back (new Coptic (1432, 11, 19));
    coptic.push_back (new Coptic (1484, 10, 14));
    coptic.push_back (new Coptic (1535, 11, 27));
    coptic.push_back (new Coptic (1555, 7, 19));
    coptic.push_back (new Coptic (1619, 8, 11));
    coptic.push_back (new Coptic (1645, 12, 19));
    coptic.push_back (new Coptic (1658, 1, 19));
    coptic.push_back (new Coptic (1659, 8, 11));
    coptic.push_back (new Coptic (1660, 1, 26));
    coptic.push_back (new Coptic (1708, 7, 8));
    coptic.push_back (new Coptic (1712, 6, 17));
    coptic.push_back (new Coptic (1755, 3, 1));
    coptic.push_back (new Coptic (1810, 11, 11));

    Calendars ethiopic;
    ethiopic.push_back (new Ethiopic (-594, 12, 6));
    ethiopic.push_back (new Ethiopic (-175, 4, 12));
    ethiopic.push_back (new Ethiopic (63, 1, 29));
    ethiopic.push_back (new Ethiopic (128, 2, 5));
    ethiopic.push_back (new Ethiopic (462, 5, 12));
    ethiopic.push_back (new Ethiopic (568, 9, 23));
    ethiopic.push_back (new Ethiopic (687, 3, 11));
    ethiopic.push_back (new Ethiopic (1005, 8, 24));
    ethiopic.push_back (new Ethiopic (1088, 9, 23));
    ethiopic.push_back (new Ethiopic (1182, 7, 20));
    ethiopic.push_back (new Ethiopic (1232, 7, 7));
    ethiopic.push_back (new Ethiopic (1280, 7, 30));
    ethiopic.push_back (new Ethiopic (1290, 8, 25));
    ethiopic.push_back (new Ethiopic (1383, 10, 10));
    ethiopic.push_back (new Ethiopic (1428, 5, 29));
    ethiopic.push_back (new Ethiopic (1484, 8, 5));
    ethiopic.push_back (new Ethiopic (1546, 1, 12));
    ethiopic.push_back (new Ethiopic (1552, 6, 29));
    ethiopic.push_back (new Ethiopic (1640, 10, 6));
    ethiopic.push_back (new Ethiopic (1672, 10, 26));
    ethiopic.push_back (new Ethiopic (1708, 11, 19));
    ethiopic.push_back (new Ethiopic (1760, 10, 14));
    ethiopic.push_back (new Ethiopic (1811, 11, 27));
    ethiopic.push_back (new Ethiopic (1831, 7, 19));
    ethiopic.push_back (new Ethiopic (1895, 8, 11));
    ethiopic.push_back (new Ethiopic (1921, 12, 19));
    ethiopic.push_back (new Ethiopic (1934, 1, 19));
    ethiopic.push_back (new Ethiopic (1935, 8, 11));
    ethiopic.push_back (new Ethiopic (1936, 1, 26));
    ethiopic.push_back (new Ethiopic (1984, 7, 8));
    ethiopic.push_back (new Ethiopic (1988, 6, 17));
    ethiopic.push_back (new Ethiopic (2031, 3, 1));
    ethiopic.push_back (new Ethiopic (2086, 11, 11));

    Calendars iso;
    iso.push_back (new ISO (-586, 29, 7));
    iso.push_back (new ISO (-168, 49, 3));
    iso.push_back (new ISO (70, 39, 3));
    iso.push_back (new ISO (135, 39, 7));
    iso.push_back (new ISO (470, 2, 3));
    iso.push_back (new ISO (576, 21, 1));
    iso.push_back (new ISO (694, 45, 6));
    iso.push_back (new ISO (1013, 16, 7));
    iso.push_back (new ISO (1096, 21, 7));
    iso.push_back (new ISO (1190, 12, 5));
    iso.push_back (new ISO (1240, 10, 6));
    iso.push_back (new ISO (1288, 14, 5));
    iso.push_back (new ISO (1298, 17, 7));
    iso.push_back (new ISO (1391, 23, 7));
    iso.push_back (new ISO (1436, 5, 3));
    iso.push_back (new ISO (1492, 14, 6));
    iso.push_back (new ISO (1553, 38, 6));
    iso.push_back (new ISO (1560, 9, 6));
    iso.push_back (new ISO (1648, 24, 3));
    iso.push_back (new ISO (1680, 26, 7));
    iso.push_back (new ISO (1716, 30, 5));
    iso.push_back (new ISO (1768, 24, 7));
    iso.push_back (new ISO (1819, 31, 1));
    iso.push_back (new ISO (1839, 13, 3));
    iso.push_back (new ISO (1903, 16, 7));
    iso.push_back (new ISO (1929, 34, 7));
    iso.push_back (new ISO (1941, 40, 1));
    iso.push_back (new ISO (1943, 16, 1));
    iso.push_back (new ISO (1943, 40, 4));
    iso.push_back (new ISO (1992, 12, 2));
    iso.push_back (new ISO (1996, 8, 7));
    iso.push_back (new ISO (2038, 45, 3));
    iso.push_back (new ISO (2094, 28, 7));

    Calendars islamic;
    islamic.push_back (new Islamic (-1245, 12, 9));
    islamic.push_back (new Islamic (-813, 2, 24)); // 23 ???
    islamic.push_back (new Islamic (-568, 4, 1));
    islamic.push_back (new Islamic (-501, 4, 6));
    islamic.push_back (new Islamic (-157, 10, 17));
    islamic.push_back (new Islamic (-47, 6, 3));
    islamic.push_back (new Islamic (75, 7, 13));
    islamic.push_back (new Islamic (403, 10, 5));
    islamic.push_back (new Islamic (489, 5, 22));
    islamic.push_back (new Islamic (586, 2, 7));
    islamic.push_back (new Islamic (637, 8, 7));
    islamic.push_back (new Islamic (687, 2, 20));
    islamic.push_back (new Islamic (697, 7, 7));
    islamic.push_back (new Islamic (793, 7, 1));
    islamic.push_back (new Islamic (839, 7, 6));
    islamic.push_back (new Islamic (897, 6, 1));
    islamic.push_back (new Islamic (960, 9, 30));
    islamic.push_back (new Islamic (967, 5, 27));
    islamic.push_back (new Islamic (1058, 5, 18));
    islamic.push_back (new Islamic (1091, 6, 2));
    islamic.push_back (new Islamic (1128, 8, 4));
    islamic.push_back (new Islamic (1182, 2, 3));
    islamic.push_back (new Islamic (1234, 10, 10));
    islamic.push_back (new Islamic (1255, 1, 11));
    islamic.push_back (new Islamic (1321, 1, 21));
    islamic.push_back (new Islamic (1348, 3, 19));
    islamic.push_back (new Islamic (1360, 9, 8));
    islamic.push_back (new Islamic (1362, 4, 13));
    islamic.push_back (new Islamic (1362, 10, 7));
    islamic.push_back (new Islamic (1412, 9, 13));
    islamic.push_back (new Islamic (1416, 10, 5));
    islamic.push_back (new Islamic (1460, 10, 12));
    islamic.push_back (new Islamic (1518, 3, 5));
    
    Calendars hindu;
    hindu.push_back (new Hindu (2515, 5, 19));
    hindu.push_back (new Hindu (2933, 9, 26));
    hindu.push_back (new Hindu (3171, 7, 11));
    hindu.push_back (new Hindu (3236, 7, 17));
    hindu.push_back (new Hindu (3570, 10, 19));
    hindu.push_back (new Hindu (3677, 2, 28));
    hindu.push_back (new Hindu (3795, 8, 17));
    hindu.push_back (new Hindu (4114, 1, 26));
    hindu.push_back (new Hindu (4197, 2, 24));
    hindu.push_back (new Hindu (4290, 12, 20));
    hindu.push_back (new Hindu (4340, 12, 7));
    hindu.push_back (new Hindu (4388, 12, 30));
    hindu.push_back (new Hindu (4399, 1, 24));
    hindu.push_back (new Hindu (4492, 3, 7));
    hindu.push_back (new Hindu (4536, 10, 28));
    hindu.push_back (new Hindu (4593, 1, 3));
    hindu.push_back (new Hindu (4654, 6, 12));
    hindu.push_back (new Hindu (4660, 11, 27));
    hindu.push_back (new Hindu (4749, 3, 1));
    hindu.push_back (new Hindu (4781, 3, 21));
    hindu.push_back (new Hindu (4817, 4, 13));
    hindu.push_back (new Hindu (4869, 3, 8));
    hindu.push_back (new Hindu (4920, 4, 20));
    hindu.push_back (new Hindu (4939, 12, 13));
    hindu.push_back (new Hindu (5004, 1, 4));
    hindu.push_back (new Hindu (5030, 5, 11));
    hindu.push_back (new Hindu (5042, 6, 15));
    hindu.push_back (new Hindu (5044, 1, 4));
    hindu.push_back (new Hindu (5044, 6, 23));
    hindu.push_back (new Hindu (5092, 12, 2));
    hindu.push_back (new Hindu (5096, 11, 11));
    hindu.push_back (new Hindu (5139, 7, 26));
    hindu.push_back (new Hindu (5195, 4, 2));

    Calendars hindu_lunar;
    hindu_lunar.push_back (new HinduLunar (2515, 6, 11));
    hindu_lunar.push_back (new HinduLunar (2933, 9, 26));
    hindu_lunar.push_back (new HinduLunar (3171, 8, 3));
    hindu_lunar.push_back (new HinduLunar (3236, 8, 9));
    hindu_lunar.push_back (new HinduLunar (3570, 11, 19));
    hindu_lunar.push_back (new HinduLunar (3677, 3, 5));
    hindu_lunar.push_back (new HinduLunar (3795, 9, 15));
    hindu_lunar.push_back (new HinduLunar (4114, 2, 7));
    hindu_lunar.push_back (new HinduLunar (4197, 2, 24));
    hindu_lunar.push_back (new HinduLunar (4291, 1, 9));
    hindu_lunar.push_back (new HinduLunar (4340, 12, 9));
    hindu_lunar.push_back (new HinduLunar (4389, 1, 23));
    hindu_lunar.push_back (new HinduLunar (4399, 2, 8));
    hindu_lunar.push_back (new HinduLunar (4492, 4, 2));
    hindu_lunar.push_back (new HinduLunar (4536, 11, 7));
    hindu_lunar.push_back (new HinduLunar (4593, 1, 3));
    hindu_lunar.push_back (new HinduLunar (4654, 7, 2));
    hindu_lunar.push_back (new HinduLunar (4660, 11, 29));
    hindu_lunar.push_back (new HinduLunar (4749, 3, 20));
    hindu_lunar.push_back (new HinduLunar (4781, 4, 4));
    hindu_lunar.push_back (new HinduLunar (4817, 5, 6));
    hindu_lunar.push_back (new HinduLunar (4869, 4, 5));
    hindu_lunar.push_back (new HinduLunar (4920, 5, 12));
    hindu_lunar.push_back (new HinduLunar (4940, 1, 13));
    hindu_lunar.push_back (new HinduLunar (5004, 1, 23));
    hindu_lunar.push_back (new HinduLunar (5030, 5, 21));
    hindu_lunar.push_back (new HinduLunar (5042, 7, 9));
    hindu_lunar.push_back (new HinduLunar (5044, 1, 15));
    hindu_lunar.push_back (new HinduLunar (5044, 7, 9));
    hindu_lunar.push_back (new HinduLunar (5092, 12, 14));
    hindu_lunar.push_back (new HinduLunar (5096, 12, 7));
    hindu_lunar.push_back (new HinduLunar (5139, 8, 14));
    hindu_lunar.push_back (new HinduLunar (5195, 4, 6));
    
    IntDows::const_iterator b = rds.begin ();
    IntDows::const_iterator e = rds.end ();
    int i = 0;
    while (b != e)
      {
        Calendars cals = init_test_checks (egyptian[i]);
        cals.push_back (armenian[i]);
        cals.push_back (gregorian[i]);
        cals.push_back (coptic[i]);
        cals.push_back (ethiopic[i]);
        cals.push_back (iso[i]);
        cals.push_back (islamic[i]);
        cals.push_back (hindu[i]);
        cals.push_back (hindu_lunar[i]);
        finish_test_checks (cals, b->first, b->second);        
        ++i; ++b;
      }
  }
}

static void 
run_test (Calendar* root_c, CalendarId id)
{
  Calendar* c = 0;
  IntCals::const_iterator b = test_dates.begin ();
  IntCals::const_iterator e = test_dates.end ();
  while (b != e)
    {
      if (c == 0)
        c = root_c->create_from_fixed (b->first);
      else
        c = root_c->update_from_fixed (b->first, c);
      if (PRINT_RESULT)
        cout << *c << endl;
      assert (*c == *b->second[id]);
      assert (c->day_of_week_from_fixed (b->first) == test_dows[b->first]);
      ++b;
    }  
  root_c->destroy (c);
}

static Calendars
init_test_checks (Calendar* c)
{
  Calendars t;
  t.push_back (c);
  return t;
}

static void
finish_test_checks (Calendars& t, int rd, util::CommonDayOfWeek dow)
{
  test_dates.push_back (make_pair(rd, t));
  test_dows[rd] = dow;
}

static void
test_egyptian ()
{
  Calendar* c = new Egyptian ();
  run_test (c, EGYPTIAN);
  delete c;
}

static void 
test_armenian ()
{
  Calendar* c = new Armenian ();
  run_test (c, ARMENIAN);
  delete c;
}

static void 
test_gregorian ()
{
  Calendar* c = new Gregorian ();
  run_test (c, GREGORIAN);
  delete c;
}

static void 
test_coptic ()
{
  Calendar* c = new Coptic ();
  run_test (c, COPTIC);
  delete c;
}

static void 
test_ethiopic ()
{
  Calendar* c = new Ethiopic ();
  run_test (c, ETHIOPIC);
  delete c;
}

static void 
test_iso ()
{
  Calendar* c = new ISO ();
  run_test (c, ISO_C);
  delete c;
}

static void 
test_islamic ()
{
  Calendar* c = new Islamic ();
  run_test (c, ISLAMIC);
  delete c;
}

static void 
test_hindu ()
{
  Calendar* c = new Hindu ();
  run_test (c, HINDU);
  delete c;
}

static void 
test_hindu_lunar ()
{
  Calendar* c = new HinduLunar ();
  run_test (c, HINDU_LUNAR);
  delete c;
}

static void test_mayan (const Rds& rds);

static void
test_exotic ()
{
  Rds rds;
  rds.push_back (-214193);
  rds.push_back (-61387);
  rds.push_back (25469);
  rds.push_back (49217);
  rds.push_back (171307);
  rds.push_back (210155);
  rds.push_back (253427);
  rds.push_back (369740);
  rds.push_back (400085);
  rds.push_back (434355);
  rds.push_back (452605);
  rds.push_back (470160);
  rds.push_back (473837);
  rds.push_back (507850);
  rds.push_back (524156);
  rds.push_back (544676);
  rds.push_back (567118);
  rds.push_back (569477);
  rds.push_back (601716);
  rds.push_back (613424);
  rds.push_back (626596);
  rds.push_back (645554);
  rds.push_back (664224);
  rds.push_back (671401);
  rds.push_back (694799);
  rds.push_back (704424);
  rds.push_back (708842);
  rds.push_back (709409);
  rds.push_back (709580);
  rds.push_back (727274);
  rds.push_back (728714);
  rds.push_back (744313);
  rds.push_back (764652);
  test_mayan (rds);
}

static void
test_mayan (const Rds& rds)
{
  Calendars mayan;
  mayan.push_back (new Mayan (6, 8, 3, 13, 9));
  mayan.push_back (new Mayan (7, 9, 8, 3, 15));
  mayan.push_back (new Mayan (8, 1, 9, 8, 11));
  mayan.push_back (new Mayan (8, 4, 15, 7, 19));
  mayan.push_back (new Mayan (9, 1, 14, 10, 9));
  mayan.push_back (new Mayan (9, 7, 2, 8, 17));
  mayan.push_back (new Mayan (9, 13, 2, 12, 9));
  mayan.push_back (new Mayan (10, 9, 5, 14, 2));
  mayan.push_back (new Mayan (10, 13, 10, 1, 7));
  mayan.push_back (new Mayan (10, 18, 5, 4, 17));
  mayan.push_back (new Mayan (11, 0, 15, 17, 7));
  mayan.push_back (new Mayan (11, 3, 4, 13, 2));
  mayan.push_back (new Mayan (11, 3, 14, 16, 19));
  mayan.push_back (new Mayan (11, 8, 9, 7, 12));
  mayan.push_back (new Mayan (11, 10, 14, 12, 18));
  mayan.push_back (new Mayan (11, 13, 11, 12, 18));
  mayan.push_back (new Mayan (11, 16, 14, 1, 0));
  mayan.push_back (new Mayan (11, 17, 0, 10, 19));
  mayan.push_back (new Mayan (12, 1, 10, 2, 18));
  mayan.push_back (new Mayan (12, 3, 2, 12, 6));
  mayan.push_back (new Mayan (12, 4, 19, 4, 18));
  mayan.push_back (new Mayan (12, 7, 11, 16, 16));
  mayan.push_back (new Mayan (12, 10, 3, 14, 6));
  mayan.push_back (new Mayan (12, 11, 3, 13, 3));
  mayan.push_back (new Mayan (12, 14, 8, 13, 1));
  mayan.push_back (new Mayan (12, 15, 15, 8, 6));
  mayan.push_back (new Mayan (12, 16, 7, 13, 4));
  mayan.push_back (new Mayan (12, 16, 9, 5, 11));
  mayan.push_back (new Mayan (12, 16, 9, 14, 2));
  mayan.push_back (new Mayan (12, 18, 18, 16, 16));
  mayan.push_back (new Mayan (12, 19, 2, 16, 16));
  mayan.push_back (new Mayan (13, 1, 6, 4, 15));
  mayan.push_back (new Mayan (13, 4, 2, 13, 14));

  Calendar* c = new Mayan ();
  Calendar* m = 0;
  Rds::const_iterator b = rds.begin ();
  Rds::const_iterator e = rds.end ();
  size_t i = 0;
  while (b != e)
    {
      if (!m)
        m = c->create_from_fixed (*b);
      else
        m = c->update_from_fixed (*b, m);
      if (PRINT_RESULT)
        cout << *mayan[i] << endl;
      assert (*mayan[i++] == *m);
      ++b;
    }
  delete m;
  delete c;
}

static void
test_conversions ()
{
  Calendar* g = new Gregorian (1819, util::AUG, 2);
  assert (Egyptian (*g) == Egyptian (2568, 2, 27));
  assert (Armenian (*g) == Armenian (1268, 11, 27));
  assert (Coptic (*g) == Coptic (1535, 11, 27));
  assert (Ethiopic (*g) == Ethiopic (1811, 11, 27));
  assert (ISO (*g) == ISO (1819, 31, 1));
  assert (Islamic (*g) == Islamic (1234, 10, 10));
  assert (Hindu (*g) == Hindu (4920, 4, 20));
  assert (HinduLunar (*g) == HinduLunar (4920, 5, 12));
  assert (Mayan (*g) == Mayan (12, 10, 3, 14, 6));
  delete g;

  g = new Gregorian (-168, util::DEC, 5);
  assert (Egyptian (*g) == Egyptian (580, 3, 6));
  assert (Armenian (*g) == Armenian (-720, 12, 6));
  assert (Coptic (*g) == Coptic (-451, 4, 12));
  assert (Ethiopic (*g) == Ethiopic (-175, 4, 12));
  assert (ISO (*g) == ISO (-168, 49, 3));
  assert (Islamic (*g) == Islamic (-813, 2, 24));
  assert (Hindu (*g) == Hindu (2933, 9, 26));
  assert (HinduLunar (*g) == HinduLunar (2933, 9, 26));
  assert (Mayan (*g) == Mayan (7, 9, 8, 3, 15));
  delete g;  
  
  g = new Gregorian (2094, util::JUL, 18);
  assert (Egyptian (*g) == Egyptian (2843, 4, 20));
  assert (Armenian (*g) == Armenian (1544, 1, 15));
  assert (Coptic (*g) == Coptic (1810, 11, 11));
  assert (Ethiopic (*g) == Ethiopic (2086, 11, 11));
  assert (ISO (*g) == ISO (2094, 28, 7));
  assert (Islamic (*g) == Islamic (1518, 3, 5));
  assert (Hindu (*g) == Hindu (5195, 4, 2));
  assert (HinduLunar (*g) == HinduLunar (5195, 4, 6));
  assert (Mayan (*g) == Mayan (13, 4, 2, 13, 14));
  delete g;  
}

static void
test ()
{
  init_tests ();
  test_egyptian ();
  test_armenian ();
  test_gregorian ();
  test_coptic ();
  test_ethiopic ();
  test_islamic ();
  test_iso ();
  test_hindu ();
  test_hindu_lunar ();
  test_exotic ();
  test_conversions ();
}
