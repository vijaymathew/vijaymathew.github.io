/*
This file is part of "The Calendar C++ Library".
See the COPYING file for licensing information.

Copyright 2012 Vijay Mathew Pandyalakal <mathew.vijay@gmail.com>
*/

#include <cmath>
#include "calendar.h"
#include "hindu.h"
using namespace std;

namespace calendar {

  const int Hindu::RD = -1132959;

  double Hindu::to_fixed_date () const
  {
    double epoch = rep_.d_epoch ();
    double year = rep_.d_year ();
    double month = rep_.d_month ();
    double day = rep_.d_day ();
    return (ceil (epoch + year * arya_solar_year () 
                  + (month - 1) * arya_solar_month ()
                  + day - util::hr (30)));
  }

  Calendar* Hindu::create_from_fixed (double date)
  {   
    return update_from_fixed (date, new Hindu ());
  }

  Calendar* Hindu::update_from_fixed (double date, Calendar* c)
  {    
    double sun = day_count (date) + util::hr (6);
    double year = floor (sun/arya_solar_year ());
    double month = util::mod (floor (sun/arya_solar_month ()), 12.0f) + 1.0f;
    double day = floor (util::mod (sun, arya_solar_month ())) + 1.0f;
    Hindu* ret = dynamic_cast<Hindu*> (c);
    ret->rep_ = ThreePartRepresentation (rep_.d_epoch (), year, month, day);
    return c;
  }

  static bool is_hindu (Calendar* c)
  {
    return (dynamic_cast<Hindu*> (c) != 0);
  }

  void Hindu::destroy (Calendar* c)
  {   
    if (is_hindu (c)) delete c;
  }

  double Hindu::jovian_year (double date)
  {
    double p = (1.0f/12.0f) * arya_jovian_period ();
    return (util::amod (27.0f + floor (day_count (date)/p), 60));
  }
  
}
