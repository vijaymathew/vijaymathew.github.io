/*
This file is part of "The Calendar C++ Library".
See the COPYING file for licensing information.

Copyright 2012 Vijay Mathew Pandyalakal <mathew.vijay@gmail.com>
*/

#include "calendar.h"
#include "egyptian.h"

const double calendar::Egyptian::RD = util::fixed_from_jd (1448638);
