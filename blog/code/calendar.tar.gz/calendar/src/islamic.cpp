/*
This file is part of "The Calendar C++ Library".
See the COPYING file for licensing information.

Copyright 2012 Vijay Mathew Pandyalakal <mathew.vijay@gmail.com>
*/

#include <cmath>
#include "calendar.h"
#include "gregorian.h"
#include "islamic.h"
using namespace std;

namespace calendar {

  const int Islamic::RD = 227015; // 622 CE, july 16 (julian).

  bool Islamic::is_leap_year () const
  {
    return (util::mod ((14.0f + 11.0f * rep_.d_year ()), 30) < 11.0f);
  }

  double Islamic::nth_kday (double n, double k) const
  {
    Gregorian g (rep_.d_year (), rep_.d_month (), rep_.d_day ());
    return g.nth_kday (n, k);
  }

  double Islamic::to_fixed_date () const
  {
    double year = rep_.d_year ();
    double month = rep_.d_month ();
    double day = rep_.d_day ();
    return (RD - 1 + (year - 1) * 354 
            + floor (1.0f / 30.0f * (3 + 11 * year))
            + 29 * (month - 1) + floor (month/2) + day);
  }

  Calendar* Islamic::create_from_fixed (double date)
  {   
    return update_from_fixed (date, new Islamic ());
  }

  Calendar* Islamic::update_from_fixed (double date, Calendar* c)
  {    
    double year = floor (1.0f/10631.0f * (30.0f * (date - RD) + 10646.0f));
    Islamic is1 (year, 1, 1);
    double prior_days = date - is1.to_fixed_date ();
    double month = floor (1.0f/325.0f * (11.0f * prior_days + 330.0f));
    Islamic is2 (year, month, 1);
    double day = 1 + date - is2.to_fixed_date ();
    Islamic* ret = dynamic_cast<Islamic*> (c);
    ret->rep_ = ThreePartRepresentation (rep_.d_epoch (), year, month, day);
    return c;
  }

  static bool is_islamic (Calendar* c)
  {
    return (dynamic_cast<Islamic*> (c) != 0);
  }

  void Islamic::destroy (Calendar* c)
  {   
    if (is_islamic (c)) delete c;
  }
  
}
