/*
This file is part of "The Calendar C++ Library".
See the COPYING file for licensing information.

Copyright 2012 Vijay Mathew Pandyalakal <mathew.vijay@gmail.com>
*/

#include "calendar.h"
#include "armenian.h"

const double calendar::Armenian::RD = 201443;
