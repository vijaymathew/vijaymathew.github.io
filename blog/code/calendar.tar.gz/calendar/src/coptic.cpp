/*
This file is part of "The Calendar C++ Library".
See the COPYING file for licensing information.

Copyright 2012 Vijay Mathew Pandyalakal <mathew.vijay@gmail.com>
*/

#include <cmath>
#include "calendar.h"
#include "gregorian.h"
#include "coptic.h"
using namespace std;

namespace calendar {

  static int coptic_epoch () 
  {
    Gregorian g (284, util::AUG, 29);
    return static_cast<int> (g.to_fixed_date ());
  }

  const int Coptic::RD = coptic_epoch ();

  bool Coptic::is_leap_year () const
  {
    int y = static_cast<int> (util::mod (rep_.d_year (), 4));
    return (y == 3);
  }

  double Coptic::nth_kday (double n, double k) const
  {
    Gregorian g (rep_.d_year (), rep_.d_month (), rep_.d_day ());
    return g.nth_kday (n, k);
  }

  double Coptic::to_fixed_date () const
  {
    double epoch = rep_.d_epoch ();
    double year = rep_.d_year ();
    double month = rep_.d_month ();
    double day = rep_.d_day ();
    return (epoch - 1.0f + 365.0f * (year - 1) + floor (year / 4.0f)
            + 30.0f * (month - 1) + day);
  }

  Calendar* Coptic::create_from_fixed (double date)
  {   
    return update_from_fixed (date, new Coptic ());
  }

  Calendar* Coptic::update_from_fixed (double date, Calendar* c)
  {    
    double year = floor (1.0f / 1461.0f * (4 * (date - rep_.d_epoch ()) + 1463.0f));
    Calendar* cal = new Coptic (year, 1, 1);
    double month = 1 + floor (1.0f / 30.0f * (date - cal->to_fixed_date ()));
    delete cal;
    cal = new Coptic (year, month, 1);
    double day = date + 1 - cal->to_fixed_date ();
    delete cal;
    Coptic* ret = dynamic_cast<Coptic*> (c);
    ret->rep_ = ThreePartRepresentation (rep_.d_epoch (), year, month, day);
    return c;
  }

  static bool is_coptic (Calendar* c)
  {
    return (dynamic_cast<Coptic*> (c) != 0);
  }

  void Coptic::destroy (Calendar* c)
  {   
    if (is_coptic (c)) delete c;
  }
  
}
