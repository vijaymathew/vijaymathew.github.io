/*
This file is part of "The Calendar C++ Library".
See the COPYING file for licensing information.

Copyright 2012 Vijay Mathew Pandyalakal <mathew.vijay@gmail.com>
*/

#include <cmath>
#include "calendar.h"
#include "hindu.h"
#include "hindu_lunar.h"
using namespace std;

namespace calendar {

  const int HinduLunar::RD = -1132959;

  bool HinduLunar::is_leap_year () const
  {
    double p = 23902504679.0f/1282400064.0f;
    return (util::mod ((rep_.d_year () * Hindu::arya_solar_year ()
                        - Hindu::arya_solar_month ()),
                       arya_lunar_month ())
            >= p);
  }

  double HinduLunar::to_fixed_date () const
  {
    double epoch = rep_.d_epoch ();
    double year = rep_.d_year ();
    double month = rep_.d_month ();
    double day = rep_.d_day ();
    double asmn = Hindu::arya_solar_month ();
    double mina = (12 * year - 1) * asmn;
    double alm = arya_lunar_month ();
    double lunar_new_year = alm * (floor (mina/alm) + 1);
    double m = 0.0f;
    double p = (lunar_new_year - mina) / (asmn - alm);
    if (!is_leap_year () && (ceil (p) <= month))
      m = month;
    else
      m = month - 1.0f;
    double d = epoch + lunar_new_year + alm * m + (day - 1) * alm - util::hr (6);
    return ceil (d);
  }

  Calendar* HinduLunar::create_from_fixed (double date)
  {   
    return update_from_fixed (date, new HinduLunar ());
  }

  Calendar* HinduLunar::update_from_fixed (double date, Calendar* c)
  {    
    double sun = Hindu::day_count (date + util::hr (6));
    double almn = arya_lunar_month ();
    double asmn = Hindu::arya_solar_month ();
    double new_moon = sun - (util::mod (sun, almn));
    bool leap = (asmn - almn >= (util::mod (new_moon, asmn) > 0));
    double month = util::mod (ceil (new_moon/asmn), 12) + 1;
    double day = util::mod (floor (sun/arya_lunar_day ()), 30) + 1;
    double year = ceil ((new_moon + asmn) / Hindu::arya_solar_year ()) - 1;
    HinduLunar* ret = dynamic_cast<HinduLunar*> (c);
    ret->rep_ = ThreePartRepresentation (rep_.d_epoch (), year, month, day);
    return c;
  }

  static bool is_hindu (Calendar* c)
  {
    return (dynamic_cast<HinduLunar*> (c) != 0);
  }

  void HinduLunar::destroy (Calendar* c)
  {   
    if (is_hindu (c)) delete c;
  }
  
}
