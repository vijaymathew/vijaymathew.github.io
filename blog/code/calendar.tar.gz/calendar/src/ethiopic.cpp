/*
This file is part of "The Calendar C++ Library".
See the COPYING file for licensing information.

Copyright 2012 Vijay Mathew Pandyalakal <mathew.vijay@gmail.com>
*/

#include <cmath>
#include "calendar.h"
#include "gregorian.h"
#include "coptic.h"
#include "ethiopic.h"
using namespace std;

namespace calendar {

  const int Ethiopic::RD = 2796;

  bool Ethiopic::is_leap_year () const
  {
    Coptic c (rep_.d_year (), rep_.d_month (), rep_.d_day ());
    return c.is_leap_year ();
  }
  double Ethiopic::nth_kday (double n, double k) const
  {
    Gregorian g (rep_.d_year (), rep_.d_month (), rep_.d_day ());
    return g.nth_kday (n, k);
  }

  double Ethiopic::to_fixed_date () const
  {
    Coptic c (rep_.d_year (), rep_.d_month (), rep_.d_day ());
    return (rep_.d_epoch () + c.to_fixed_date () - Coptic::epoch ());
  }

  Calendar* Ethiopic::create_from_fixed (double date)
  {   
    return update_from_fixed (date, new Ethiopic ());
  }
  
  Calendar* Ethiopic::update_from_fixed (double date, Calendar* c)
  {    
    Coptic copt (rep_.d_year (), rep_.d_month (), rep_.d_day ());
    Calendar* cal = copt.create_from_fixed (date + Coptic::epoch () - rep_.d_epoch ());
    Simple* s = dynamic_cast<Simple*> (cal);
    Ethiopic* ret = dynamic_cast<Ethiopic*> (c);
    ret->rep_ = s->rep ();
    copt.destroy (cal);
    return c;
  }

  static bool is_ethiopic (Calendar* c)
  {
    return (dynamic_cast<Ethiopic*> (c) != 0);
  }

  void Ethiopic::destroy (Calendar* c)
  {   
    if (is_ethiopic (c)) delete c;
  }
  
}
