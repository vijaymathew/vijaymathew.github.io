/*
This file is part of "The Calendar C++ Library".
See the COPYING file for licensing information.

Copyright 2012 Vijay Mathew Pandyalakal <mathew.vijay@gmail.com>
*/

#ifndef HINDU_LUNAR_H_
#define HINDU_LUNAR_H_

#include "simple.h"

namespace calendar {
  class HinduLunar : public Simple
  {
  public:
    HinduLunar () : Simple (RD) { }
    HinduLunar (double year, double month, 
                double day) : Simple (RD, year, month, day) { }
    HinduLunar (const Calendar& c) : Simple (RD)
    {
      HinduLunar *e = dynamic_cast<HinduLunar*> (create_from_fixed (c.to_fixed_date ()));
      *this = *e;
      destroy (e);
    }

    virtual double to_fixed_date () const;
    virtual Calendar* create_from_fixed (double date);
    virtual Calendar* update_from_fixed (double date, Calendar* c);
    virtual void destroy (Calendar* c);
    virtual bool is_leap_year () const;

    static double arya_lunar_month ()
    {
      return (1577917500.0f/53433336.0f);
    }

    static double arya_lunar_day ()
    {
      return ((1.0f/30.0f) * arya_lunar_month ());
    }

  private:
    static const int RD;    
  };  
}

#endif // HINDU_LUNAR_H_
