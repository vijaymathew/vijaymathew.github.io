/*
This file is part of "The Calendar C++ Library".
See the COPYING file for licensing information.

Copyright 2012 Vijay Mathew Pandyalakal <mathew.vijay@gmail.com>
*/

#ifndef ISLAMIC_H_
#define ISLAMIC_H_

#include "simple.h"

namespace calendar {
  class Islamic : public Simple
  {
  public:
    Islamic () : Simple (RD) { }
    Islamic (double year, double month, 
             double day) : Simple (RD, year, month, day) { }
    Islamic (double year, util::CommonMonth month, 
             double day) : Simple (RD, year, 
                                   static_cast<double> (month), 
                                   day) { }
    Islamic (const Calendar& c) : Simple (RD)
    {
      Islamic *e = dynamic_cast<Islamic*> (create_from_fixed (c.to_fixed_date ()));
      *this = *e;
      destroy (e);
    }

    virtual double to_fixed_date () const;
    virtual Calendar* create_from_fixed (double date);
    virtual Calendar* update_from_fixed (double date, Calendar* c);
    virtual void destroy (Calendar* c);
    virtual double nth_kday (double n, double k) const;
    virtual bool is_leap_year () const;
  private:
    static const int RD;    
  };  
}

#endif // ISLAMIC_H_

