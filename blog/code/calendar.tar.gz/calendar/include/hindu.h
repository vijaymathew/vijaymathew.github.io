/*
This file is part of "The Calendar C++ Library".
See the COPYING file for licensing information.

Copyright 2012 Vijay Mathew Pandyalakal <mathew.vijay@gmail.com>
*/

#ifndef HINDU_H_
#define HINDU_H_

#include "simple.h"

namespace calendar {
  class Hindu : public Simple
  {
  public:
    Hindu () : Simple (RD) { }
    Hindu (double year, double month, 
            double day) : Simple (RD, year, month, day) { }
    Hindu (const Calendar& c) : Simple (RD)
    {
      Hindu *e = dynamic_cast<Hindu*> (create_from_fixed (c.to_fixed_date ()));
      *this = *e;
      destroy (e);
    }

    virtual double to_fixed_date () const;
    virtual Calendar* create_from_fixed (double date);
    virtual Calendar* update_from_fixed (double date, Calendar* c);
    virtual void destroy (Calendar* c);

    static double day_count (double date) 
    { 
      return (date - RD);
    }

    static double arya_solar_year ()
    {
      return (1577917500.0f/4320000.0f);
    }

    static double arya_solar_month ()
    {
      return ((1.0f/12.0f) * arya_solar_year ());
    }

    static double arya_jovian_period ()
    {
      return (1577917500.0f/364224.0f);
    }

    static double jovian_year (double date);

  private:
    static const int RD;    
  };  
}

#endif // HINDU_H_
