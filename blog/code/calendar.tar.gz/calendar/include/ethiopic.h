/*
This file is part of "The Calendar C++ Library".
See the COPYING file for licensing information.

Copyright 2012 Vijay Mathew Pandyalakal <mathew.vijay@gmail.com>
*/

#ifndef ETHIOPIC_H_
#define ETHIOPIC_H_

#include "simple.h"

namespace calendar {
  class Ethiopic : public Simple
  {
  public:
    Ethiopic () : Simple (RD) { }
    Ethiopic (double year, double month, 
              double day) : Simple (RD, year, month, day) { }
    Ethiopic (double year, util::CommonMonth month, 
              double day) : Simple (RD, year, 
                                    static_cast<double> (month), 
                                    day) { }
    Ethiopic (const Calendar& c) : Simple (RD) 
    { 
      Ethiopic *e = dynamic_cast<Ethiopic*> (create_from_fixed (c.to_fixed_date ()));
      *this = *e;
      destroy (e);
    }

    virtual double to_fixed_date () const;
    virtual Calendar* create_from_fixed (double date);
    virtual Calendar* update_from_fixed (double date, Calendar* c);
    virtual void destroy (Calendar* c);
    virtual double nth_kday (double n, double k) const;
    virtual bool is_leap_year () const;

  private:
    static const int RD;    
  };  
}

#endif // ETHIOPIC_H_
