/*
This file is part of "The Calendar C++ Library".
See the COPYING file for licensing information.

Copyright 2012 Vijay Mathew Pandyalakal <mathew.vijay@gmail.com>
*/

#ifndef ARMENIAN_H_
#define ARMENIAN_H_

#include "simple.h"

namespace calendar {  
  class Armenian : public Simple
  {
  public:
    Armenian () : Simple (RD) { }
    Armenian (double year, double month, double day) : Simple(RD, year, 
                                                              month, day)
    { }
    Armenian (const Calendar& c) : Simple (c, RD) { }
  private:
    static const double RD;
  };
}

#endif // EGYPTIAN_H_
