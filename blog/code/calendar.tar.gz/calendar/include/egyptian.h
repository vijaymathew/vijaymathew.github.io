/*
This file is part of "The Calendar C++ Library".
See the COPYING file for licensing information.

Copyright 2012 Vijay Mathew Pandyalakal <mathew.vijay@gmail.com>
*/

#ifndef EGYPTIAN_H_
#define EGYPTIAN_H_

#include "simple.h"

namespace calendar {  
  class Egyptian : public Simple
  {
  public:
    Egyptian () : Simple (RD) { }
    Egyptian (double year, double month, double day) : Simple(RD, year, 
                                                              month, day)
    { }
    Egyptian (const Calendar& c) : Simple (c, RD) { }
  private:
    static const double RD;
  };
}

#endif // EGYPTIAN_H_
