(ns url-shortner.core
  (:require [cheshire.core :as json]
            [url-shortner.encoder :as e]
            [url-shortner.spark :refer :all]
            [url-shortner.store :as store]))

(def config (read-string (slurp "./config.edn")))

(def db (store/open-connection (:store config)))

(defn post-handler
  [request]
  (let [r (json/parse-string (:body request) true)
        url (:url r)
        short-url (e/encode url)]
    (store/set-data db short-url url)
    {:status 200
     :headers {:Content-Type "application/json"}
     :body (json/generate-string {:hash short-url})}))

(defn get-handler
  [request]
  (if-let [url (store/get-data db (:hash (:params request)))]
    {:status 302
     :headers {:Location url}}
    {:status 404
     :body "Not Found"}))

(defn -main
  []
  (port! (:web-server-port config))

  (GET "/:hash" get-handler)
  (POST "/" post-handler))
